<?

$idmateria	= @$_REQUEST['idmateria'];
$mes 		= @$_REQUEST['mes'];

echo "
	<div class='demo-charts mdl-color--green-700 mdl-color-text--white mdl-shadow--4dp mdl-cell--6-col mdl-grid'>
		  <div class='mdl-layout-spacer'></div>
		  <div class='android-section-title mdl-typography--display-1-color-contrast'>
	 		  <i class='mdl-color-text--green-A700 material-icons' role='presentation'>timeline</i> HISTORIAL
		  </div>
		  <div class='mdl-layout-spacer'></div>
	</div>
	<div class='demo-charts mdl-color--green-700 mdl-color-text--white mdl-shadow--2dp mdl-cell--3-col mdl-grid'>
		<div class='mdl-layout-spacer'></div>
		<details>
		 	<summary class='mdl-color-text--white'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>date_range</i> FILTRAR POR MES</summary>
			  <form method='post' action='./'>
			  	"; 
			  	if ($idmateria) {
			  		echo "<input type='hidden' name='idmateria' value='$idmateria'>";
			  	}
			  	echo"
				  <div id='mes' class='android-section-title mdl-typography--display-1-color-contrast'>
			 		<input class='mdl-textfield__input'  type='month' name='mes' value='$mes' >
			 		<center>
			 			<button name='contenido' value='mis_intentos' class='mdl-shadow--4dp mdl-color-text--white mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--white material-icons' role='presentation'>check</i> APLICAR</button>
			 		</center>
				  </div>
			  </form>
		</details>

		  <div class='mdl-layout-spacer'></div>
	</div>

	    <div class='demo-charts mdl-color--green-300 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
	          <div class='mdl-layout-spacer'></div>
	            <div class='mdl-color--green-300 mdl-card--expand mdl-cell mdl-card mdl-cell--12-col mdl-cell--12-col-phone'>
	              <center>
				  <table class='mdl-color--white mdl-data-table  mdl-shadow--2dp mdl-js-data-table'>
				    <thead>
				      <tr>
				      	<th>
						    <span class='mdl-shadow--4dp mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon' id='materia'>
					         <i class='mdl-color-text--green-A700 material-icons'>class</i>	
					        </span>
					        <form method='post' action='./'>
					        <ul class='mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-left' for='materia'>
		  						<input type='hidden' name='contenido' value='mis_intentos'>
		  						";
		  						if ($mes) {
									echo "<input type='hidden' name='mes' value='$mes'>";
		  						}
		  							ver_vitacora_materia ();		  							
		  						
		  					echo"
		  						<li><center><button name='general' class='mdl-color-text--blue-700 mdl-button mdl-js-button mdl-js-ripple-effect'>general</button></center></li>
					        </ul>
					        </form>
				      	</th>
						<th><i class='mdl-color-text--green-A700 material-icons'>school</i> NOTA</th>
				        <th><center><i id='fecha' class='mdl-color-text--green-A700 material-icons'>date_range</i></center></th>
							<div class='mdl-color--green-700 mdl-tooltip' for='fecha'>
                 				 FECHA
            				</div>
				        <th><center><i id='hora' class='mdl-color-text--green-A700 material-icons'>watch_later</i></center></th>
							<div class='mdl-color--green-700 mdl-tooltip' for='hora'>
                 				 HORA
                 			</div>
						<th><center><i id='suma' class='mdl-color-text--green-A700 material-icons'>add_circle</i> </center></th>
							<div class='mdl-color--green-700 mdl-tooltip' for='suma'>
                 				 RESPUESTAS CORRECTAS
            				</div> 
				        <th><center><i id='resta' class='mdl-color-text--green-A700 material-icons'>remove_circle</i> </center></th>
							<div class='mdl-color--green-700 mdl-tooltip' for='resta'>
                 				 RESPUESTAS INCORRECTAS	
            				</div>
				      </tr>
				    </thead>
				    <tbody>
				  </center>
					";

						vitacora_sesiones_materia ($idmateria,$mes);

				echo "
				    </tbody>
				  </table>
	            </div>
	          <div class='mdl-layout-spacer'></div>
		</div>
";
?>