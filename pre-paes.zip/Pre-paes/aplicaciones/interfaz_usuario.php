<?
$idusuario = $_SESSION["idusuario"];

echo "
	<div class='demo-charts mdl-color--green-700 mdl-color-text--white mdl-shadow--4dp mdl-cell--7-col mdl-grid'>
		  <div class='mdl-layout-spacer'></div>
		  <div class='android-section-title mdl-typography--display-1-color-contrast'>
	 		MIS PUNTUACIONES MÁXIMAS
		  </div>
		  <div class='mdl-layout-spacer'></div>
	</div>
		<div class='mdl-grid'>
	        <div class='demo-charts mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
	              <div class='demo-card-square-blue mdl-cell mdl-card mdl-cell--3-col mdl-shadow--4dp'>
	                  <div class='mdl-card__title'>
					    <span class='mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon' id='socia'>
				         <i class='material-icons'>more_vert</i>
				        </span>
				        <ul class='mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-left' for='socia'>
				        <form method='post' action='./'>
	  						<input type='hidden' name='contenido' value='test_sesion'>
				         	<button name='idmateria' value='1' class='mdl-color-text--blue-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--blue-A700 material-icons' role='presentation'>fitness_center</i> INICIAR TEST</button>
				      	</form>
				        </ul>
	                  	<h2 class='mdl-card__title-text'>ESTUDIOS SOCIALES</h2>
	                  </div>
	                  <div class='mdl-color--blue-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>
	                  ";
	                  $idmateria = 1; 

	                  mejor_nota_materia ($idmateria, $idusuario);
	                  echo "

	                  </div>

	              </div>
	              <div class='demo-card-square-green mdl-cell mdl-card mdl-cell--3-col mdl-shadow--4dp'>
	                  <div class='mdl-card__title'>
					    <span class='mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon' id='cien'>
				         <i class='material-icons'>more_vert</i>
				        </span>
				        <ul class='mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-left' for='cien'>
				        <form method='post' action='./'>
	  						<input type='hidden' name='contenido' value='test_sesion'>
				         	<button name='idmateria' value='3' class='mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>fitness_center</i> INICIAR TEST</button>
				        </form>
				        </ul>
	                    <h2 class='mdl-card__title-text'>CIENCIAS NATURALES</h2>
	                  </div>
	                  <div class='mdl-color--green-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>
	                  ";
	                  $idmateria = 3; 

	                  mejor_nota_materia ($idmateria, $idusuario);
	                  echo "
	                  </div>
	              </div>
	              <div class='demo-card-square-orange mdl-cell mdl-card mdl-cell--3-col mdl-shadow--4dp'>
	                  <div class='mdl-card__title'>
					    <span class='mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon' id='len'>
				         <i class='material-icons'>more_vert</i>
				        </span>
				        <ul class='mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-left' for='len'>
				        <form method='post' action='./'>
	  						<input type='hidden' name='contenido' value='test_sesion'>
				         	<button name='idmateria' value='4' class='mdl-color-text--orange-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--orange-A700 material-icons' role='presentation'>fitness_center</i> INICIAR TEST</button>
				        </form>
				        </ul>
	                    <h2 class='mdl-card__title-text'>LENGUAJE Y LITERATURA</h2>
	                  </div>
	                  <div class='mdl-color--orange-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>
	                  ";
	                  $idmateria = 4; 

	                  mejor_nota_materia ($idmateria, $idusuario);
	                  echo "
	                  </div>
	              </div>
	              <div class='demo-card-square-red mdl-cell mdl-card mdl-cell--3-col mdl-shadow--4dp'>
	                  <div class='mdl-card__title'>
					    <span class='mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon' id='mate'>
				         <i class='material-icons'>more_vert</i>
				        </span>
				        <ul class='mdl-menu mdl-js-menu mdl-js-ripple-effect mdl-menu--bottom-left' for='mate'>
				        <form method='post' action='./'>
	  						<input type='hidden' name='contenido' value='test_sesion'>
				         	<button name='idmateria' value='2' class='mdl-color-text--red-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--red-A700 material-icons' role='presentation'>fitness_center</i> INICIAR TEST</button>
				        </form>
				        </ul>
	                    <h2 class='mdl-card__title-text'>MATEMÁTICA</h2>
	                  </div>
	                  <div class='mdl-color--red-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>
	                  ";
	                  $idmateria = 2; 

	                  mejor_nota_materia ($idmateria, $idusuario);
	                  echo "
	                  </div>
	              </div>
	     	</div>
	        <div class='demo-charts mdl-cell mdl-color--white mdl-shadow--2dp mdl-cell--12-col mdl-grid'>
	              <div class='mdl-cell mdl-layout-spacer'></div>
	              <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--4-col mdl-shadow--4dp'>
	                  <div class='mdl-card__title'>
	                  	<h2 class='mdl-card__title-text'>PROMEDIO</h2>
	                  </div>
	                  <div class='mdl-color--cyan-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>

	                  	"; 
	                  	mostrar_promedio ($idusuario);

	                  	echo "
	                  	 

	                  </div>
	              </div>
				  <div class='mdl-cell mdl-layout-spacer'></div>	
			</div>
		</div>
	</form>
";
?>