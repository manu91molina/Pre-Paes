<?
$cryptinstall="./funciones/crypt/cryptographp.fct.php";
include $cryptinstall;
$areglo_respuestas   = @ $_REQUEST['areglo_respuestas'];
$idmateria           = @ $_REQUEST['idmateria'];

$areglo_respuestas   = unserialize($areglo_respuestas);

#evaluacion en base a :
#########################
$total_preguntas = 10;  #
#########################
$respuestas_buenas  = array ();
$respuestas_malas   = array ();


for ( $contador = 0 ; $contador < $total_preguntas; $contador ++ ){

    $idask_literal  = $areglo_respuestas[$contador];

    $idask_econtrado_areglo = strstr($idask_literal, ' ', true); // Desde PHP 5.3.0
    $literal                = strstr($idask_literal, ' ');
    $literal                = reemplazar_espacio ($literal);
    
    #echo "$idask_econtrado_areglo y $literal <br>";
    $vector_encontrar_respuesta = consultar("select * from opcion where ask_idask=$idask_econtrado_areglo and truefalse_idtruefalse=2 and literal='$literal';");
   	$existe_respuesta = count( $vector_encontrar_respuesta );
   	if ( $existe_respuesta > 0 ) {
      $agregando_correcta = array_push( $respuestas_buenas, "$idask_econtrado_areglo" );
   		#echo "respuestas correctas <br>";
   	 }else{
      $agregando_erroneas = array_push( $respuestas_malas, "$idask_econtrado_areglo" );
     }

}





$total_respuestas_buenas = count($respuestas_buenas);
$total_respuestas_malas  = $total_preguntas - $total_respuestas_buenas;
#echo "Respuestas buenas: $total_respuestas_buenas <br>";
#echo "Respuestas malas: $total_respuestas_malas <br>";

#print_r($areglo_respuestas);
#print_r($respuestas_buenas);

# fórmula en base a nota 10 (100%)
$nota_materia      = ($total_respuestas_buenas / $total_preguntas) * 10;
$porcentaje_buenas = ($total_respuestas_buenas * 100) / $total_preguntas;
$porcentaje_malas  = ($total_respuestas_malas * 100) / $total_preguntas;

## verificar materia para asignar estilo de las cards
  switch ($idmateria) {
    case '1':
      $materia        = "sociales";
      $paint_mdl      = "blue-900";
      $paint_mdl_text = "blue-A100";
      $demo_card_square_color = "demo-card-square-blue";
      $mdl_progress   = "mdl-progress-blue";
      break;
    case '2':
      $materia        = "matematicas";
      $paint_mdl      = "red-900";
      $paint_mdl_text = "red-300";
      $demo_card_square_color = "demo-card-square-red";
      $mdl_progress   = "mdl-progress-red";
      break;
    case '3':
      $materia        = "ciencias";
      $paint_mdl      = "green-900";
      $paint_mdl_text = "green-600";
      $demo_card_square_color = "demo-card-square-green";
      $mdl_progress   = "mdl-progress-green";
      break;
    case '4':
      $materia        = "lenguaje";
      $paint_mdl      = "orange-900";
      $paint_mdl_text = "orange-A200";
      $demo_card_square_color = "demo-card-square-orange";
      $mdl_progress   = "mdl-progress-orange";
      break;
    
    default:
      # code...
      break;
  }


  $mdl_cell_mostrar_nota = 3;
  $mdl_cell_mostrar_formulario = 4;

  if ($total_respuestas_malas == 0) {
    $mdl_cell_mostrar_nota = 6;
    $mdl_cell_mostrar_formulario = 6;
  }

##########################



echo "
<div class='mdl-grid'>
            <div class='demo-charts mdl-color--cyan mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
              <div class='$demo_card_square_color mdl-card mdl-shadow--2dp mdl-cell mdl-cell--$mdl_cell_mostrar_nota-col'>
                <div class='mdl-card__title'>
                  <h2 class='mdl-card__title-text'>Resultado de ";materia ($materia);echo"</h2>
                </div>  
                <div class='demo-card-event mdl-shadow--2dp'>
                  <div class='mdl-card__title'>
                  <div class='mdl-card__actions'>
                    <h4>
                      <div class='javascript chart' data-percent='$porcentaje_buenas'>
                          <span class='percent'>nota</span>
                          <p><span class='mdl-badge' data-badge='$nota_materia'>NOTA</span></p>
                      </div>
                    </h4>
                  </div>

                  </div>
                  <div class='mdl-card__actions mdl-card--border'>
                    Respuestas erroneas: $total_respuestas_malas<br>
                    Respuestas acertadas: $total_respuestas_buenas <br>
                  </div>
                </div>            
              </div>";
            #mostrar referencia para estudio
            if ($total_respuestas_malas > 0) {
              echo "
              <div class='demo-card-square-amber mdl-cell mdl-card mdl-cell--5-col mdl-shadow--2dp'>
                  <div class='mdl-card__title'>
                    <h2 class='mdl-card__title-text'>Puedes reforzarte en:</h2>
                  </div>  
                  <div class='mdl-tabs mdl-card__supporting-text mdl-cell--18-col'>
                           ";
                            mostrar_referencias ($respuestas_malas);
              echo "
                  </div>
              </div>
              ";
            }



                echo"

              <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--$mdl_cell_mostrar_formulario-col mdl-shadow--2dp'>
                  <div class='mdl-card__title mdl-card--expand'>
                    <h2 class='mdl-card__title-text'>¿Ya te registraste?</h2>
                  </div>
                  <div class='mdl-card__supporting-text mdl-cell--12-col'>
                    <form action='./'  onSubmit='return validarPasswd()' method='post'>
                      <input type='hidden' name='contenido' value='creando_cuenta'>
                      <input type='hidden' name='idmateria' value='$idmateria'>
                      <input type='hidden' name='porcentaje_buenas' value='$porcentaje_buenas'>
                      <input type='hidden' name='total_respuestas_malas' value='$total_respuestas_malas'>
                      <input type='hidden' name='total_respuestas_buenas' value='$total_respuestas_buenas'>
                      <input type='hidden' name='nota_materia' value='$nota_materia'>

                     ";
                     if ($total_respuestas_malas > 0) {
                      $respuestas_malas = serialize($respuestas_malas);
                      echo "<input type='hidden' name='respuestas_malas' value='$respuestas_malas'>";
                     }

                  echo "
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' name='correo'  type='email' required>
                        <label class='mdl-textfield__label' for='correo'>CORREO</label>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id='nombres' class='mdl-textfield__input' id='nombres' name='nombres'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='nombres'>NOMBRES</label>
                        <div class='mdl-tooltip' for='nombres'>
                          solo letras y espacios
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='apellidos' class='mdl-textfield__input' name='apellidos'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='apellidos'>APELLIDOS</label>
                        <div class='mdl-tooltip' for='apellidos'>
                          solo letras y espacios
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <select class='mdl-textfield__input'  name='departamento' id='buscar_departamento' required>
                        ";
                          lista_departamentos ();
                        echo"
                        </select>
                        <label class='mdl-textfield__label' for='departamento'>DEPARTAMENTO</label>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input list='buscar' id='instituto' class='mdl-textfield__input' name='instituto' required>
                        <label class='mdl-textfield__label' for='instituto'>INSTITUTO EDUCATIVO</label>
                        ";
                        lista_institutos ();
                        echo"
                        <div class='mdl-tooltip' for='instituto'>
                          solo letras y espacios
                        </div>
                      </div>

                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword1' pattern='.{8,}' title='mínimo 8 caracteres' class='mdl-textfield__input' name='pass1'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword1'>CREAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword1'>
                          mínimo 8 caracteres
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword2' pattern='.{8,}' title='mínimo 8 caracteres' class='mdl-textfield__input' name='pass2'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword2'>CONFIRMAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword2'>
                          deben coincidir ambas contraseñas
                        </div>
                      </div>
                      <script src='./recursos/guiones/04-mensajes.js'></script>


                      ";
                       dsp_crypt(0,1);
                  echo " 
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' name='codigo'  type='text' id='codigo' required>
                        <label class='mdl-textfield__label' for='codigo'>ESCRIBE EL TEXTO</label>
                        <div class='mdl-tooltip' for='codigo'>
                          los caracteres deben coincidir <br> con los de la imagen
                        </div>
                        <script language='JavaScript'>
                         validaRequerido( 'codigo' );
                       </script>
                      </div>
                    <center>    
                      <input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='CREAR CUENTA'>
                    </center>
                    </form>
                  </div>
              </div>

            </div>



</div>
 


<script src='./recursos/easypiechart.js'></script>
<script>
  window.onload = function() {
  <!--  selecciono la clase javascript -->
      var javascript = document.querySelector('.javascript');
      new EasyPieChart(javascript, {
          <!-- activo la animación y establezco su duración a un segundo -->
          animate: ({ duration: 1500, enabled: true }),
          <!-- aumento la longitud de las lineas de la gráfica -->
          scaleLength:10,
          <!-- aumento el tamaño de la gráfica -->
          size:150,
          barColor:'#2196f3',
          <!-- añado el número del porcentaje que se muestra en el span -->
          onStep: function(from, to, percent) {
              this.el.children[0].innerHTML = Math.round(percent);
          }
      });
}

</script>

";



?>
