<?

echo "
	<div class='demo-charts mdl-color--green-700 mdl-color-text--white mdl-shadow--4dp mdl-cell--6-col mdl-grid'>
		  <div class='mdl-layout-spacer'></div>
		  <div class='android-section-title mdl-typography--display-1-color-contrast'>
	 		  <i class='mdl-color-text--green-A700 material-icons' role='presentation'>build</i> MODIFICAR CUENTA
		  </div>
		  <div class='mdl-layout-spacer'></div>
	</div>
	<div class='mdl-grid'>
	    <div class='demo-charts mdl-color--green-300 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>

			<center>
			<div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--5-col mdl-shadow--2dp'>
			  <form action='./'  onSubmit='return validarPasswd()' method='post'>
          <input type='hidden' name='contenido' value='actualizando_cuenta'>";
          editar_cuenta ();

          echo "<details>";
            echo "<summary class='mdl-color-text--green-700'>Cambiar Contraseña<i class='mdl-color-text--green-A700 material-icons'>vpn_key</i></summary>";
            echo "
                     <div class='mdl-textfield mdl-color-text--green-700 mdl-js-textfield mdl-textfield--floating-label'>
                       <input id ='pass_actual' pattern='.{8,}' class='mdl-textfield__input' name='pass_actual'  type='password' >
                       <label class='mdl-textfield__label mdl-color-text--green-700' for='pass_actual'>CONTRASEÑA ACTUAL</label>
                       <div class='mdl-tooltip' for='pass_actual'>
                         introduce tu contraseña actual
                       </div>
                     </div>
                      <div class='mdl-color-text--green-700 mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword1' pattern='.{8,}' title='mínimo 8 caracteres' class='mdl-textfield__input' name='pass1'  type='password' >
                        <label class='mdl-textfield__label mdl-color-text--green-700' for='pssword1'>NUEVA CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword1'>
                          mínimo 8 caracteres
                        </div>
                      </div>
                      <div class='mdl-color-text--green-700 mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword2' pattern='.{8,}' class='mdl-textfield__input' name='pass2'  type='password' >
                        <label class='mdl-textfield__label mdl-color-text--green-700' for='pssword2'>CONFIRMAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword2'>
                          deben coincidir ambas contraseñas
                        </div>
                      </div>
                      <script src='./recursos/guiones/04-mensajes.js'></script>";

          echo "</details>";


      echo"
              <p><center>    
                <input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='ACTUALIZAR CUENTA'>
              </p></center>
        </form>

			</div>

			</center>

		</div>
	</div>
";

?>