<?

############ Captura de variables ########################################################
$total_preguntas      = @ $_REQUEST['total_preguntas'];
$idmateria  = @ $_REQUEST['idmateria'];
$idask      = @ $_REQUEST['idask'];
$options      = @ $_REQUEST['options'];
$ask_vista      = @ $_REQUEST['ask_vista'];
#echo "-".$ask_vista_siguiente      = @ $_REQUEST['ask_vista_siguiente'];
$en_curso_areglo_ask= @ $_REQUEST['areglo_ask'];
$selec_areglo_ask   = unserialize($en_curso_areglo_ask);

#print_r($selectec_areglo_ask);
$areglo_respuestas   = @ $_REQUEST['areglo_respuestas'];

if ($areglo_respuestas) {
  $areglo_respuestas   = unserialize($areglo_respuestas);
  #print_r($areglo_respuestas);
}

$respuesta = "$idask $options";


########### proceso de respuetas ##############################################
if (!isset($_POST['areglo_respuestas'])) {
  #generar areglo vacio
  $areglo_respuestas = array ();
  #echo "holas";
}else{
  if ($options) {
      $contador;
       $posicion = -1;
      for( $contador=0; $contador < count($areglo_respuestas); $contador++ ){
           if( $areglo_respuestas[$contador] == "$respuesta"){
               $posicion = $contador;
               break;
          }
      }
      if( $posicion == -1 ){

        for ( $contador = 0 ; $contador < count($areglo_respuestas); $contador ++ ){
            $idask_literal  = $areglo_respuestas[$contador];
            $idask_econtrado_areglo = strstr($idask_literal, ' ', true); // Desde PHP 5.3.0
            $idask_econtrado_respuesta = strstr($respuesta, ' ', true); // Desde PHP 5.3.0
            #echo $idask_econtrado_areglo."<br>"; // mostrará idask
            #echo "<br> respuesta $idask_econtrado_respuesta <br>";
            if ($idask_econtrado_respuesta == $idask_econtrado_areglo) {
              $editar=TRUE;
              #echo "este id-$idask_econtrado_areglo se encontró en la posición [$contador] <br>";
              break;
            }
            #break;
        }

        if (!$editar) {
          $cantidad = array_push( $areglo_respuestas, "$respuesta" );
        }else{
          $areglo_respuestas [$contador] = "$respuesta";
          #echo "array editado <br>"; 
        }

         #echo "<br>$cantidad";
          #print_r($areglo_respuestas);

      }else{
          #echo "<br> id-$respuesta está en la posición [".$posicion."] <br>";
          #print_r($areglo_respuestas);
      }
  }

}



###################### random materia ####################################################
if (!$idmateria) {
  $idmateria = rand(1, 4);
}

############ especificando nombre para consulta a la base de datos #####################
  switch ($idmateria) {
    case '1':
      $materia        = "sociales";
      $paint_mdl      = "blue-900";
      $paint_mdl_text = "blue-A100";
      $demo_card_square_color = "demo-card-square-blue";
      $mdl_progress   = "mdl-progress-blue";
      break;
    case '2':
      $materia        = "matematicas";
      $paint_mdl      = "red-900";
      $paint_mdl_text = "red-300";
      $demo_card_square_color = "demo-card-square-red";
      $mdl_progress   = "mdl-progress-red";
      break;
    case '3':
      $materia        = "ciencias";
      $paint_mdl      = "green-900";
      $paint_mdl_text = "green-600";
      $demo_card_square_color = "demo-card-square-green";
      $mdl_progress   = "mdl-progress-green";
      break;
    case '4':
      $materia        = "lenguaje";
      $paint_mdl      = "orange-900";
      $paint_mdl_text = "orange-A200";
      $demo_card_square_color = "demo-card-square-orange";
      $mdl_progress   = "mdl-progress-orange";
      break;
    
    default:
      # code...
      break;
  }




 
#################################### random y areglo de preguntas ###################################   


if (!$en_curso_areglo_ask) {
  #version modificada para 10 prguntas
       $vector_ask = consultar("select * from ask where materia_idmateria = $idmateria order by idask asc;");
       #echo $total_preguntas = count($vector_ask);

       ######### total de preguntas para un test ###############
        $total_preguntas = 10;                                 #
       #########################################################

       #####  total de preguntas que existen en la tabla ask   #
       ####         de la base de datos                     ####
        $vector_preguntas = consultar("select * from ask ;");
        $cantidad_preguntas = count( $vector_preguntas );
        $bd_total_preguntas = $cantidad_preguntas + 1;
       #########################################################

        $cantidad_ask = 1;
        if ( $cantidad_ask > 0 ) {
          for ( $contador = 0 ; $contador < 1; $contador ++ ) {
             $min_idask      = $vector_ask[$contador]['idask'];
          }
        }
        $vector_ask = consultar("select * from ask where materia_idmateria = '$idmateria' and idask <> '$bd_total_preguntas' order by idask desc;");
        $cantidad_ask = 1;
        if ( $cantidad_ask > 0 ) {
          for ( $contador = 0 ; $contador < 1; $contador ++ ) {
            $max_idask      = $vector_ask[$contador]['idask'];
          }
        }

        # funcion que prepara random $total_preguntas
         $areglo_ask = Array();
         reset($areglo_ask);
         for($i=1;$i<=$total_preguntas;$i++) 
         {
           $areglo_ask[$i]=mt_rand($min_idask,$max_idask);
            if($i>1) 
            {
               for($x=1; $x<$i; $x++)
               {
                 if($areglo_ask[$i]==$areglo_ask[$x]) 
                 { 
                   $i--; 
                   break; 
                 }
              }
           }
         }

       #echo " - ".$idask = mt_rand($min_idask, $max_idask);
}   

include "./configuraciones/principal.php";
echo "
      <!--encabezado-->
      <div class='android-content'>
        <div class='android-be-together-section mdl-typography--text-center'>
          <div class='android-font android-slogan'>$NOMBRE_SISTEMA</div>
          ";

 $progreso = count($areglo_respuestas);
 $porcentaje = ($progreso * 100) / $total_preguntas;
echo "
        </div>
      </div>
      <!--cierre encabezado-->

            <!--barra de progreso-->
            <div id='p1' style='height:10px; width:auto;' class='mdl-color--$paint_mdl_text mdl-shadow--8dp $mdl_progress mdl-js-progress'></div>
            <script>
              document.querySelector('#p1').addEventListener('mdl-componentupgraded', function() {
                this.MaterialProgress.setProgress($porcentaje);
              });
            </script>
            <!--fin barra progreso-->
";

echo "
<div class='demo-charts mdl-color--$paint_mdl mdl-shadow--2dp mdl-cell--3-col mdl-grid'>
<form method='post' action='./'>
";

if ($areglo_ask) {
 $serializado = serialize($areglo_ask);
}else{
 $serializado = serialize($selec_areglo_ask);
}

if ($areglo_ask) {
  #echo "$areglo_ask";
        for ( $i = 0 ; $i <= $total_preguntas; $i ++ ) {
           $idask_areglo      = $areglo_ask[$i];
            #$indice = 1 + $contador;
            #echo "$id ";
            if ($i<=$total_preguntas && $i <> 0) {

             #echo "<td>";
                  #echo "<form  method='post' action='./'>";
                  #echo "$idask_areglo";
                  echo "<input type='hidden' name='idmateria' value='$idmateria'>";
                  echo "<input type='hidden' name='contenido' value='demo_test'>";
                  #echo "<input type='hidden' name='areglo_ask' value='$serializado'>";
                  #echo "<button name='ask_vista' value='$i' class ='mdl-color-text--$paint_mdl_text mdl-button mdl-js-button mdl-button--fab mdl-button--mini-fab'>$i</button>";
                  echo "<button name='ask_vista' value='$i' class ='mdl-color-text--$paint_mdl_text mdl-button mdl-js-button mdl-button--accent'>$i</button>";

                   #echo "</form>";
             #echo "</td>";
           }
        }
}else {
        for ( $i = 0 ; $i <= $total_preguntas; $i ++ ) {
           $idask_areglo      = $selec_areglo_ask[$i];
            #$indice = 1 + $i;
           #echo "$idask_areglo ";
            if ($i<=$total_preguntas && $i <> 0) {
                  echo "<input type='hidden' name='idask' value='$idask_areglo'>";
                  echo "<input type='hidden' name='idmateria' value='$idmateria'>";
                  echo "<input type='hidden' name='contenido' value='demo_test'>";
                  #echo "<input type='hidden' name='areglo_ask' value='$serializado'>";
                  #echo "<button name='ask_vista' value='$i' class ='mdl-color-text--$paint_mdl_text mdl-button mdl-js-button mdl-button--fab mdl-button--mini-fab'>$i</button>";
                  echo "<button name='ask_vista' value='$i' class ='";
                  if ($ask_vista == $i) {
                    echo "mdl-color-text--$paint_mdl_text mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect";
                  }else{
                     echo"mdl-color-text--$paint_mdl_text mdl-button mdl-js-button mdl-button--accent";
                  }
                  echo "'>$i</button>";
           }
        }
}        

if ($porcentaje == 100) {
  echo "<button name='calificar' value='calificar' class='mdl-button mdl-js-button mdl-js-ripple-effect'>¿ENTREGAR AHORA?<i class='material-icons'>playlist_add_check</i></button>";
}

echo "
</div>

";

echo "
     <div class='mdl-grid'>
        <div class='mdl-grid demo-content'>
          <div class='demo-charts mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>        
            <div class='$demo_card_square_color mdl-shadow--2dp'>
              <div class='mdl-card__title '>

                <h2 class='mdl-card__title-text'>";materia ($materia);echo"</h2>
              </div>              
              <div class='mdl-tabs mdl-card__supporting-text'>
";

/*if ($ask_vista_anterior) {
  $ask_vista = $ask_vista_anterior;
}else{
  $ask_vista = $ask_vista_siguiente;
}*/

switch ($ask_vista) {
  case '1':
    $idask = $selec_areglo_ask['1'];
    break;
  case '2':
    $idask = $selec_areglo_ask['2'];
    break;
  case '3':
    $idask = $selec_areglo_ask['3'];
    break;
  case '4':
    $idask = $selec_areglo_ask['4'];
    break;
  case '5':
    $idask = $selec_areglo_ask['5'];
    break;
  case '6':
    $idask = $selec_areglo_ask['6'];
    break;
  case '7':
    $idask = $selec_areglo_ask['7'];
    break;
  case '8':
    $idask = $selec_areglo_ask['8'];
    break;
  case '9':
    $idask = $selec_areglo_ask['9'];
    break;
  case '10':
    $idask = $selec_areglo_ask['10'];
    break;
  case '11':
    $idask = $selec_areglo_ask['11'];
    break;
  case '12':
    $idask = $selec_areglo_ask['12'];
    break;
  case '13':
    $idask = $selec_areglo_ask['13'];
    break;
  case '14':
    $idask = $selec_areglo_ask['14'];
    break;
  case '15':
    $idask = $selec_areglo_ask['15'];
    break;
  case '16':
    $idask = $selec_areglo_ask['16'];
    break;
  case '17':
    $idask = $selec_areglo_ask['17'];
    break;
  case '18':
    $idask = $selec_areglo_ask['18'];
    break;
  case '19':
    $idask = $selec_areglo_ask['19'];
    break;
  case '20':
    $idask = $selec_areglo_ask['20'];
    break;
  case '21':
    $idask = $selec_areglo_ask['21'];
    break;
  case '22':
    $idask = $selec_areglo_ask['22'];
    break;
  case '23':
    $idask = $selec_areglo_ask['23'];
    break;
  case '24':
    $idask = $selec_areglo_ask['24'];
    break;
  case '25':
    $idask = $selec_areglo_ask['25'];
    break;

  default:
    $idask = $areglo_ask['1'];
    break;
}

/**if ($areglo_ask) {
  $idask = $areglo_ask[1];
}else{
  $idask = $selec_areglo_ask[1];
}**/


       if ($ask_vista){echo "$ask_vista- ";}else{echo "1- ";}ask_con_img ($idask);
       echo"
              </div>

              <div class='mdl-tabs mdl-js-tabs mdl-js-ripple-effect'>
                <div class='mdl-tabs__tab-bar'>
                    <a href='#starks-panel' class='mdl-tabs__tab is-active'>OPCIONES</a>
                </div>

                <div class='mdl-tabs__panel is-active' id='starks-panel'>
       ";
              echo"<ol>
                  ";listar_opciones($idask);
              echo"
                  </ol>";

for ( $contador = 0 ; $contador < count($areglo_respuestas); $contador ++ ) {
    $idask_literal  = $areglo_respuestas[$contador];
    if ($idask == $idask_literal) {
      #echo "$idask_literal y $idask";
      $literal = strstr($idask_literal, ' ');
      #echo "<br>".$literal."<br>";
      break;
    }
}


echo "                  
                </div>
              </div>
                 

              <!--opciones-->
              <div class='mdl-card__actions mdl-card--border'>
                <b>RESPUESTA</b>
                <center><table class='mdl-data-table'>
                  <thead>
                    <tr>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-1'>
                          <input type='radio' id='option-1' class='mdl-radio__button' name='options' value='a'"; if($literal == " a"){echo " checked";} echo" />
                            A.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-2'>
                          <input type='radio' id='option-2' class='mdl-radio__button' name='options' value='b'"; if($literal == " b"){echo " checked";} echo"/>
                            B.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-3'>
                          <input type='radio' id='option-3' class='mdl-radio__button' name='options' value='c'"; if($literal == " c"){echo " checked";} echo"/>
                            C.<span class='mdl-color--deep-purple mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-4'>
                          <input type='radio' id='option-4' class='mdl-radio__button' name='options' value='d'"; if($literal == " d"){echo " checked";} echo"/>
                            D.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                    </tr>
                  </thead>
                </table></center>
";
if (!$areglo_respuestas) {
  $areglo_respuestas = array ();
  $areglo_respuestas = serialize($areglo_respuestas);
} else {
  $areglo_respuestas = serialize($areglo_respuestas);
}


echo "
                <input type='hidden' name='idmateria' value='$idmateria'>
                <input type='hidden' name='contenido' value='demo_test'>
                <input type='hidden' name='areglo_ask' value='$serializado'>
                <input type='hidden' name='areglo_respuestas' value='$areglo_respuestas'>
                <input type='hidden' name='idask' value='$idask'>
                <input type='hidden' name='total_preguntas' value='$total_preguntas'>

                <!-- Accent-colored raised button with ripple -->
                <button name='ask_vista' value='"; 
                switch ($ask_vista) {
                  #editado para evalucion de 10 preguntaS #
                  case '1':                               #
                    echo "10";                            #
                    break;                                #
                  #########################################
                  case '2':
                    echo "1";
                    break;
                  case '3':
                    echo "2";
                    break;
                  case '4':
                    echo "3";
                    break;
                  case '5':
                    echo "4";
                    break;
                  case '6':
                    echo "5";
                    break;
                  case '7':
                    echo "6";
                    break;
                  case '8':
                    echo "7";
                    break;
                  case '9':
                    echo "8";
                    break;
                  case '10':
                    echo "9";
                    break;
                  case '11':
                    echo "10";
                    break;
                  case '12':
                    echo "11";
                    break;
                  case '13':
                    echo "12";
                    break;
                  case '14':
                    echo "13";
                    break;
                  case '15':
                    echo "14";
                    break;
                  case '16':
                    echo "15";
                    break;
                  case '17':
                    echo "16";
                    break;
                  case '18':
                    echo "17";
                    break;
                  case '19':
                    echo "18";
                    break;
                  case '20':
                    echo "19";
                    break;
                  case '21':
                    echo "20";
                    break;
                  case '22':
                    echo "21";
                    break;
                  case '23':
                    echo "22";
                    break;
                  case '24':
                    echo "23";
                    break;
                  case '25':
                    echo "24";
                    break;                  
                  default:
                    echo "1";
                    break;
                }
                echo"' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>
                  ANTERIOR
                </button>  &nbsp; &nbsp; &nbsp;";

                  switch ($ask_vista) {
                    case '10':
                      if ($progreso == 9) {
                        echo "<button name='ask_vista' value='1' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>CONTINUAR</button>";
                      }else{
                        if ($progreso ==10) {
                          echo "<button name='ask_vista' value='1' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>CONTINUAR</button>";
                        }else{
                          boton_siguiente ($ask_vista);
                        }
                      }
                      break;                    
                    default:
                      boton_siguiente ($ask_vista);
                      break;
                  }

                echo"
              </form>
              </div>
            </div>
          </div>
        </div>
      </div>
";
?>
