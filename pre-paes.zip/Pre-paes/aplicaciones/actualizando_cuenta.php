<?

if ($_SESSION["correo"]) {echo "<link rel='stylesheet' href='./recursos/material.indigo-pink.min.css'>";}
 $pass_actual            = @ $_REQUEST['pass_actual'];
 $correo_nuevo           = @ $_REQUEST['correo'];
 $nombres                = @ $_REQUEST['nombres'];
 $apellidos              = @ $_REQUEST['apellidos'];
 $clave1                 = @ $_REQUEST['pass1'];
 $clave2                 = @ $_REQUEST['pass2'];

#correo en uso ##################
$correo  = $_SESSION["correo"]; #
#################################
$soporte_correo = "soportesoftware@uls.edu.sv";

echo "
  <div class='demo-charts mdl-color--green-700 mdl-color-text--white mdl-shadow--4dp mdl-cell--6-col mdl-grid'>
      <div class='mdl-layout-spacer'></div>
      <div class='android-section-title mdl-typography--display-1-color-contrast'>
        <i class='mdl-color-text--green-A700 material-icons' role='presentation'>build</i> MODIFICANDO CUENTA
      </div>
      <div class='mdl-layout-spacer'></div>
  </div>
  <div class='mdl-grid'>
    <div class='demo-charts mdl-color--green-300 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>

      <div class='mdl-layout-spacer'></div>
      <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--6-col mdl-shadow--2dp'>
        <ul class='demo-list-icon mdl-list'>

";

  if ($correo_nuevo) {

    $vector_usuario = consultar("select * from usuario where correo = '{$correo_nuevo}';");
    $cantidad_usuarios = count( $vector_usuario );
    if ($cantidad_usuarios) {
          echo "
              <li class='mdl-list__item mdl-list__item--three-line'>
                <span class='mdl-list__item-primary-content'>
                  <i class='material-icons mdl-color-text--green-A700 mdl-list__item-icon'>check_circle</i>
                  <span>Tu correo: <b>$correo</b></span>                
                  <span class='mdl-list__item-text-body'></span>
                </span>
              </li>";
    }else{
      $sql="UPDATE usuario SET correo = '{$correo_nuevo}' WHERE correo = '$correo';";
      $update = ejecutar( $sql );

      $_SESSION["correo"] = NULL;
      unset( $_SESSION["correo"] );
      $_SESSION["correo"]    = $correo_nuevo;
      
      $mensaje ="Notificación:  Haz actulizado el correo en tu cuenta, ahora estas registrado con $correo_nuevo ."."\n"."Si tu no has realizado la modificación escribenos a: $soporte_correo";
      mail($correo, "TEST PRE-PAES", $mensaje, "FROM: Universidad Luterana Salvadoreña");
      echo "
          <li class='mdl-list__item mdl-list__item--three-line'>
            <span class='mdl-list__item-primary-content'>
              <i class='material-icons mdl-color-text--green-A700 mdl-list__item-icon'>check_circle</i>
              <span>Actualizaste el correo, ahora estas registrado con <b>$correo_nuevo</b></span>
            </span>
          </li>";
    }
  }

  if ($nombres || $apellidos) {
    #correo en uso ##################
    $correo  = $_SESSION["correo"]; #
    #################################
    $vector_usuario = consultar("select * from usuario where correo = '{$correo}' and nombres = '{$nombres}' and apellidos = '$apellidos';");
    $cantidad_usuarios = count( $vector_usuario );
    if ($cantidad_usuarios) {
          echo "
              <li class='mdl-list__item mdl-list__item--three-line'>
                <span class='mdl-list__item-primary-content'>
                  <i class='material-icons mdl-color-text--green-A700 mdl-list__item-icon'>check_circle</i>
                  <span>Nombre de usuario: <b>$nombres $apellidos</b></span>                
                  <span class='mdl-list__item-text-body'></span>
                </span>
              </li>";
    }else{
      $sql="UPDATE usuario SET nombres = '{$nombres}', apellidos = '{$apellidos}' WHERE correo = '$correo';";
      $update = ejecutar( $sql );
      $mensaje ="Notificación:  Haz editado tu nombre de usuario."."\n"."Si tu no has realizado la modificación escribenos a: $soporte_correo";
      mail($correo, "TEST PRE-PAES", $mensaje, "FROM: Universidad Luterana Salvadoreña");
      
      $_SESSION["nombres"] = NULL;
      unset( $_SESSION["nombres"] );
      $_SESSION["nombres"]  = $nombres;
      $_SESSION["apellidos"] = NULL;
      unset( $_SESSION["apellidos"] );
      $_SESSION["apellidos"]  = $nombres;

          echo "
              <li class='mdl-list__item mdl-list__item--three-line'>
                <span class='mdl-list__item-primary-content'>
                  <i class='material-icons mdl-color-text--green-A700 mdl-list__item-icon'>check_circle</i>
                  <span>Editado nombre de usuario: <b>$nombres $apellidos</b></span>                
                  <span class='mdl-list__item-text-body'></span>
                </span>
              </li>";
    }
  }

    if ( $clave1 == $clave2) {
    #echo "coinciden";
      $correo       = $_SESSION["correo"];
      $pass_actual  = md5($pass_actual);
        $vector_usuario = consultar("select * from usuario where correo = '{$correo}' and pass = '{$pass_actual}';");
        $cantidad_usuarios = count( $vector_usuario );
        if ($cantidad_usuarios) {
          #echo "contraseña actual correcta";
          $clave1 =  md5($clave1);
          $sql="UPDATE usuario SET pass = '{$clave1}' WHERE correo = '$correo';";
          $update = ejecutar( $sql );

          $mensaje ="Notificación:  Haz realizado una modificación en tu contraseña."."\n"."Si tu no has realizado la modificación escribenos a: $soporte_correo";
          mail($correo, "TEST PRE-PAES", $mensaje, "FROM: Universidad Luterana Salvadoreña");
          
          echo "
              <li class='mdl-list__item'>
                <span class='mdl-list__item-primary-content'>
                  <i class='material-icons mdl-color-text--green-A700 mdl-list__item-icon'>check_circle</i>
                  Contraseña actualizada
                </span>
              </li>";

        }else{
          if ($clave1 && $clave2) {
            echo "
                <li class='mdl-list__item'>
                  <span class='mdl-list__item-primary-content'>
                    <i class='material-icons mdl-color-text--green-A700 mdl-list__item-icon'>error</i>
                    No se pudo actualizar la contraseña, introduce correctamente la contraseña actual
                  </span>
                </li>";
          }

        }

    }else{
    	echo "
      		<script language='JavaScript'>
      		   ponerError('Las Contraseñas no coinciden <br> Intenta de nuevo</center>');
      		</script>
      ";

    }
echo "
        </ul>
        <form method='post' action='./'>
          <p><center>    
            <button name='contenido' value='edit_cuenta' class='mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>settings</i> MODIFICAR DE NUEVO</button>
          </center></p>
        </form>
      </div>
      <div class='mdl-layout-spacer'></div>
      

    </div>
  </div>


";


?>