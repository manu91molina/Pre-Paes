<?
$cryptinstall="./funciones/crypt/cryptographp.fct.php";
include $cryptinstall;

echo "
    <!--encabezado-->
    <div class='android-content'>
      <a name='top'></a>
      <div class='android-be-together-section-formulario mdl-typography--text-center'>
        <div class='android-font android-slogan'>TEST PAES</div>
      </div>
    </div>
    <!--cierre encabezado-->
    ";

echo "
	<div class='mdl-grid'>
     <div class='demo-charts mdl-color--cyan-400 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
              
              <div class='mdl-layout-spacer'></div>
              <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--5-col mdl-shadow--2dp'>
                  <div class='mdl-card__title mdl-card--expand'>

                    <h2 class='mdl-card__title-text'>Crear mi cuenta</h2>
                  </div>
                  <div class='mdl-card__supporting-text mdl-cell--12-col'>
                    <form action='./'  onSubmit='return validarPasswd()' method='post'>
                      <input type='hidden' name='contenido' value='validar_usuario'>

                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' name='correo'  type='email' required>
                        <label class='mdl-textfield__label' for='correo'>CORREO</label>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id='nombres' class='mdl-textfield__input' name='nombres'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='nombres'>NOMBRES</label>
                        <div class='mdl-tooltip' for='nombres'>
                          solo letras y espacios
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='apellidos' class='mdl-textfield__input' name='apellidos'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='apellidos'>APELLIDOS</label>
                        <div class='mdl-tooltip' for='apellidos'>
                          solo letras y espacios
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <select class='mdl-textfield__input'  name='departamento' id='buscar_departamento' required>
                        ";
                          lista_departamentos ();
                        echo"
                        </select>
                        <label class='mdl-textfield__label' for='departamento'>DEPARTAMENTO</label>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input list='buscar' id='instituto' class='mdl-textfield__input' name='instituto' required>
                        <label class='mdl-textfield__label' for='instituto'>INSTITUTO EDUCATIVO</label>
                        ";
                        lista_institutos ();
                        echo"
                        <div class='mdl-tooltip' for='instituto'>
                          solo letras y espacios
                        </div>
                      </div>

                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword1' pattern='.{8,}'  class='mdl-textfield__input' name='pass1'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword1'>CREAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword1'>
                          mínimo 8 caracteres
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword2' pattern='.{8,}'  class='mdl-textfield__input' name='pass2'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword2'>CONFIRMAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword2'>
                          deben coincidir ambas contraseñas
                        </div>
                      </div>
                      <script src='./recursos/guiones/04-mensajes.js'></script>


                      ";
                       dsp_crypt(0,1);
                  echo " 
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' name='codigo'  type='text' id='codigo' required>
                        <label class='mdl-textfield__label' for='codigo'>ESCRIBE EL TEXTO</label>
                        <div class='mdl-tooltip' for='codigo'>
                          los caracteres deben coincidir <br> con los de la imagen
                        </div>
                        <script language='JavaScript'>
                         validaRequerido( 'codigo' );
                       </script>
                      </div>
                    <center>    
                      <input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='CREAR CUENTA'>
                    </center>
                    </form>
                  </div>
              </div>
			
			<div class='mdl-layout-spacer'></div>


		</div>
	</div>
";

?>