<?
$cryptinstall="./funciones/crypt/cryptographp.fct.php";
include $cryptinstall;

 $codigo                 = @ $_REQUEST['codigo'];
 $idmateria              = @ $_REQUEST['idmateria'];
 $porcentaje_buenas      = @ $_REQUEST['porcentaje_buenas'];
 $total_respuestas_malas = @ $_REQUEST['total_respuestas_malas'];
 $total_respuestas_buenas= @ $_REQUEST['total_respuestas_buenas'];
 $nota_materia           = @ $_REQUEST['nota_materia'];
 $respuestas_malas       = @ $_REQUEST['respuestas_malas'];
 $respuestas_malas       = unserialize($respuestas_malas);
 $correo                 = @ $_REQUEST['correo'];
 $nombres                = @ $_REQUEST['nombres'];
 $apellidos              = @ $_REQUEST['apellidos'];
 $departamento           = @ $_REQUEST['departamento'];
 $instituto              = @ $_REQUEST['instituto'];
 $clave1                 = @ $_REQUEST['pass1'];
 $clave2                 = @ $_REQUEST['pass2'];



  if ( $codigo ) {
    if ( chk_crypt( $codigo ) && $clave1 == $clave2) {
        $vector_usuario = consultar("select * from usuario where correo = '$correo';");
        $cantidad_usuarios = count( $vector_usuario );
        if ($cantidad_usuarios == 0) {
              $clavemd5 = md5($clave1);
              $fecha         = date("d-m-Y");
              $hora          = date ("H:i:s");
              #VERIFICAR SI EXISTE EL NOMBRE DEL INSTITUTO
              $consultar_instituto = consultar("SELECT * from instituto where instituto='{$instituto}';");
              $verficar_existencia = count($consultar_instituto);
              if ( $verficar_existencia > 0) {
                for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
                     $idinstituto   = $consultar_instituto[$contador]['idinstituto'];
                  }
              }

              if (!$idinstituto) {
                #INSERTAR UN NUEVO NOMBRE DE INSTITUTO
                $sql="INSERT INTO instituto (instituto) VALUES ('$instituto');";
                #ejecutar sql
                $registrado = ejecutar( $sql );

                #OBTENER EL ID DEL NOMBRE DEL INSTITUTO RECIEN INGRESADO
                $consultar = consultar ( "SELECT * from instituto where instituto='$instituto';");
                $verficar_existencia = count($consultar);
                if ( $verficar_existencia > 0) {
                  for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
                      $idinstituto   = $consultar[$contador]['idinstituto'];
                    }
                }

              }
              $sql="
              INSERT INTO usuario (instituto_idinstituto, nombres, apellidos, departamento, correo, pass, fecha_registro, hora_registro)
              VALUES ('$idinstituto', '$nombres', '$apellidos', '$departamento', '$correo', '{$clavemd5}', '$fecha', '$hora');";
              #ejecutar sql
              $registrado = ejecutar( $sql );
              validar_usuario_registrandose ($registrado, $correo, $clavemd5);

              echo "
                  <div class='demo-charts mdl-cell mdl-color--white mdl-shadow--2dp mdl-cell--12-col mdl-grid'>
                        <div class='mdl-cell mdl-layout-spacer'></div>
                        <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--4-col mdl-shadow--4dp'>
                            <div class='mdl-card__title'>
                              <h2 class='mdl-card__title-text'>TU CUENTA SE HA CREADO</h2>
                            </div>
                            <div class='mdl-color--cyan-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>
                               
                              Ya estas registrado $nombres $apellidos </br>
                              Recuerda que con tu  correo <u>$correo</u>  ingresarás al sistema. </br>
                                <a class='' href='./'>CONTINUAR</a>
                            </div>
                        </div>
                  <div class='mdl-cell mdl-layout-spacer'></div>  
              </div>
              ";
              include "./configuraciones/principal.php";
              $mensaje="Notificación: Bienvenido $nombres te has registrado al test pre-paes, puedes realizar multiples pruebas y revisar tu progreso."."\n"."plataformas.uls.edu.sv/prepaes";
              mail($correo, "$NOMBRE_SISTEMA", "$mensaje");
              $mensaje="Notificación: Se ha registrado un nuevo usuario $nombres con el correo $correo";
              mail($CORREO_ADMIN, "$NOMBRE_SISTEMA", "$mensaje");
              
        }else{
          echo "
          <div class='mdl-color--white mdl-layout__header-row'>
            <span class='mdl-color-text--cyan mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='!'>
              Este correo $correo ya esta registrado.
            </span> 
          </div>";
          include "./aplicaciones/demo_test.php";
        }

    }else{
    	echo "
		<script language='JavaScript'>
		   ponerError('Captcha introducida es incorrecto <center>o contraseñas no coinciden</center>');
		</script>";
      ## verificar materia para asignar estilo de las cards
        switch ($idmateria) {
          case '1':
            $materia        = "sociales";
            $paint_mdl      = "blue-900";
            $paint_mdl_text = "blue-A100";
            $demo_card_square_color = "demo-card-square-blue";
            $mdl_progress   = "mdl-progress-blue";
            break;
          case '2':
            $materia        = "matematicas";
            $paint_mdl      = "red-900";
            $paint_mdl_text = "red-300";
            $demo_card_square_color = "demo-card-square-red";
            $mdl_progress   = "mdl-progress-red";
            break;
          case '3':
            $materia        = "ciencias";
            $paint_mdl      = "green-900";
            $paint_mdl_text = "green-600";
            $demo_card_square_color = "demo-card-square-green";
            $mdl_progress   = "mdl-progress-green";
            break;
          case '4':
            $materia        = "lenguaje";
            $paint_mdl      = "orange-900";
            $paint_mdl_text = "orange-A200";
            $demo_card_square_color = "demo-card-square-orange";
            $mdl_progress   = "mdl-progress-orange";
            break;
          
          default:
            # code...
            break;
        }
      $mdl_cell_mostrar_nota = 3;
      $mdl_cell_mostrar_formulario = 4;

      if ($total_respuestas_malas == 0) {
        $mdl_cell_mostrar_nota = 6;
        $mdl_cell_mostrar_formulario = 6;
      }     
      ##



      echo "
      <div class='mdl-grid'>
                  <div class='demo-charts mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
                    <div class='$demo_card_square_color mdl-card mdl-shadow--2dp mdl-cell mdl-cell--$mdl_cell_mostrar_nota-col'>
                      <div class='mdl-card__title'>
                        <h2 class='mdl-card__title-text'>Resultado de ";materia ($materia);echo"</h2>
                      </div>  
                      <div class='demo-card-event mdl-shadow--2dp'>
                        <div class='mdl-card__title'>
                        <div class='mdl-card__actions'>
                          <h4>
                            <div class='javascript chart' data-percent='$porcentaje_buenas'>
                                <span class='percent'>nota</span>
                                <p><span class='mdl-badge' data-badge='$nota_materia'>NOTA</span></p>
                            </div>
                          </h4>
                        </div>

                        </div>
                        <div class='mdl-card__actions mdl-card--border'>
                          Respuestas erroneas: $total_respuestas_malas<br>
                          Respuestas acertadas: $total_respuestas_buenas <br>
                        </div>
                      </div>            
                    </div>";


                  if ($total_respuestas_malas > 0) {
                    echo "
                    <div class='demo-card-square-yellow mdl-cell mdl-card mdl-cell--5-col mdl-shadow--2dp'>
                        <div class='mdl-card__title'>
                          <h2 class='mdl-card__title-text'>Puedes reforzarte en:</h2>
                        </div>  
                        <div class='mdl-tabs mdl-card__supporting-text mdl-cell--18-col'>
                                 ";
                                  mostrar_referencias ($respuestas_malas);
                    echo "
                        </div>
                    </div>
                    ";
                  }



                echo"

              <div class='demo-card-square-white mdl-cell mdl-card mdl-cell--$mdl_cell_mostrar_formulario-col mdl-shadow--2dp'>
                  <div class='mdl-card__title mdl-card--expand'>
                    <h2 class='mdl-card__title-text'>¿Ya te registraste?</h2>
                  </div>
                  <div class='mdl-card__supporting-text mdl-cell--12-col'>
                    <form action='./'  onSubmit='return validarPasswd()' method='post'>
                      <input type='hidden' name='contenido' value='creando_cuenta'>
                      <input type='hidden' name='idmateria' value='$idmateria'>
                      <input type='hidden' name='porcentaje_buenas' value='$porcentaje_buenas'>
                      <input type='hidden' name='total_respuestas_malas' value='$total_respuestas_malas'>
                      <input type='hidden' name='total_respuestas_buenas' value='$total_respuestas_buenas'>
                      <input type='hidden' name='nota_materia' value='$nota_materia'>
                     ";
                     if ($total_respuestas_malas > 0) {
                      $respuestas_malas = serialize($respuestas_malas);
                      echo "<input type='hidden' name='respuestas_malas' value='$respuestas_malas'>";
                     }

                  echo "
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' value='$correo' name='correo'  type='email' required>
                        <label class='mdl-textfield__label' for='correo'>CORREO</label>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id='nombres' class='mdl-textfield__input' value='$nombres' id='nombres' name='nombres'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='nombres'>NOMBRES</label>
                        <div class='mdl-tooltip' for='nombres'>
                          solo letras y espacios
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='apellidos' class='mdl-textfield__input' value='$apellidos' name='apellidos'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='apellidos'>APELLIDOS</label>
                        <div class='mdl-tooltip' for='apellidos'>
                          solo letras y espacios
                        </div>
                      </div>";
                      if ($clave1 <> $clave2) {
                        #mensaje contraseña no coinciden
                        $mensaje_contraseña = "HACER COINDIR LAS CONTRASEÑAS";
                        $clave1 = NULL;
                        $clave2 = NULL;
                      }else{
                        $mensaje_contraseña = "CREAR CONTRASEÑA";
                      }

                      echo"
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword1' pattern='.{8,}' value='$clave1'  class='mdl-textfield__input' name='pass1'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword1'>$mensaje_contraseña</label>
                        <div class='mdl-tooltip' for='pssword1'>
                          mínimo 8 caracteres
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword2' pattern='.{8,}' value='$clave2'  class='mdl-textfield__input' name='pass2'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword2'>CONFIRMAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword2'>
                          deben coincidir ambas contraseñas
                        </div>
                      </div>
                      <script src='./recursos/guiones/04-mensajes.js'></script>


                      ";
                       dsp_crypt(0,1);
                  echo " 
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' name='codigo'  type='text' id='codigo' required>
                        <label class='mdl-textfield__label' for='codigo'>ESCRIBE EL TEXTO</label>
                        <div class='mdl-tooltip' for='codigo'>
                          los caracteres deben coincidir <br> con los de la imagen
                        </div>
                        <script language='JavaScript'>
                         validaRequerido( 'codigo' );
                       </script>
                      </div>
                    <center>    
                      <input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='CREAR CUENTA'>
                    </center>
                    </form>
                  </div>
              </div>

            </div>



</div>       


      <script src='./recursos/easypiechart.js'></script>
      <script>
      window.onload = function() {
      <!--  selecciono la clase javascript -->
          var javascript = document.querySelector('.javascript');
          new EasyPieChart(javascript, {
              <!-- activo la animación y establezco su duración a un segundo -->
              animate: ({ duration: 1500, enabled: true }),
              <!-- aumento la longitud de las lineas de la gráfica -->
              scaleLength:10,
              <!-- aumento el tamaño de la gráfica -->
              size:150,
              barColor:'#17C1C7',
              <!-- añado el número del porcentaje que se muestra en el span -->
              onStep: function(from, to, percent) {
                  this.el.children[0].innerHTML = Math.round(percent);
              }
          });
      }
       
      </script>

";


    }
  }


?>