<?
$cryptinstall="./funciones/crypt/cryptographp.fct.php";
include $cryptinstall;

 $codigo                 = @ $_REQUEST['codigo'];
 $correo                 = @ $_REQUEST['correo'];
 $nombres                = @ $_REQUEST['nombres'];
 $apellidos              = @ $_REQUEST['apellidos'];
 $departamento           = @ $_REQUEST['departamento'];
 $instituto              = @ $_REQUEST['instituto'];
 $clave1                 = @ $_REQUEST['pass1'];
 $clave2                 = @ $_REQUEST['pass2'];



  if ( $codigo ) {
    if ( chk_crypt( $codigo ) && $clave1 == $clave2) {
        $vector_usuario = consultar("select * from usuario where correo = '$correo';");
        $cantidad_usuarios = count( $vector_usuario );
        if ($cantidad_usuarios == 0) {
              $clavemd5 = md5($clave1);
              $fecha         = date("d-m-Y");
              $hora          = date ("H:i:s");

              #VERIFICAR SI EXISTE EL NOMBRE DEL INSTITUTO
              $consultar_instituto = consultar("SELECT * from instituto where instituto='{$instituto}';");
              $verficar_existencia = count($consultar_instituto);
              if ( $verficar_existencia > 0) {
                for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
                     $idinstituto   = $consultar_instituto[$contador]['idinstituto'];
                  }
              }

              if (!$idinstituto) {
                #INSERTAR UN NUEVO NOMBRE DE INSTITUTO
                $sql="INSERT INTO instituto (instituto) VALUES ('$instituto');";
                #ejecutar sql
                $registrado = ejecutar( $sql );

                #OBTENER EL ID DEL NOMBRE DEL INSTITUTO RECIEN INGRESADO
                $consultar = consultar ( "SELECT * from instituto where instituto='$instituto';");
                $verficar_existencia = count($consultar);
                if ( $verficar_existencia > 0) {
                  for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
                      $idinstituto   = $consultar[$contador]['idinstituto'];
                    }
                }

              }

              $sql="
              INSERT INTO usuario (instituto_idinstituto, nombres, apellidos, departamento, correo, pass, fecha_registro, hora_registro)
              VALUES ('$idinstituto', '$nombres', '$apellidos', '$departamento', '$correo', '{$clavemd5}', '$fecha', '$hora');";
              #ejecutar sql
              $registrado = ejecutar( $sql );
              validar_usuario_registrandose ($registrado, $correo, $clavemd5);
              echo "
                  <div class='demo-charts mdl-cell mdl-color--white mdl-shadow--2dp mdl-cell--12-col mdl-grid'>
                        <div class='mdl-cell mdl-layout-spacer'></div>
                        <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--4-col mdl-shadow--4dp'>
                            <div class='mdl-card__title'>
                              <h2 class='mdl-card__title-text'>TU CUENTA SE HA CREADO</h2>
                            </div>
                            <div class='mdl-color--cyan-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>
                               
                              Ya estas registrado $nombres $apellidos </br>
                              Recuerda que con tu  correo <u>$correo</u> </br> ingresarás al sistema. </br>
                                <center><a class='' href='./'>CONTINUAR</a></center>
                            </div>
                        </div>
                  <div class='mdl-cell mdl-layout-spacer'></div>  
              </div>
              ";
              include "./configuraciones/principal.php";
              $mensaje="Notificación: Bienvenido $nombres te has registrado al test pre-paes, puedes realizar multiples pruebas y revisar tu progreso."."\n"."plataformas.uls.edu.sv/prepaes";
              mail($correo, "$NOMBRE_SISTEMA", "$mensaje");
              $mensaje="Notificación: Se ha registrado un nuevo usuario $nombres con el correo $correo";
              mail($CORREO_ADMIN, "$NOMBRE_SISTEMA", "$mensaje");
              
        }else{
          echo "
          <div class='mdl-color--white mdl-layout__header-row'>
            <span class='mdl-color-text--cyan mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='!'>
              Este correo $correo ya esta registrado.
            </span> 
          </div>";
          include "./aplicaciones/demo_test.php";
        }

    }else{
    	echo "
		<script language='JavaScript'>
		   ponerError('Captcha introducida es incorrecto <center>o contraseñas no coinciden</center>');
		</script>";


      echo "
      <div class='mdl-grid'>
        <div class='demo-charts mdl-color--cyan-400 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>

            <div class='mdl-layout-spacer'></div>

            <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--5-col mdl-shadow--2dp'>
                  <div class='mdl-card__title mdl-card--expand'>
                    <h2 class='mdl-card__title-text'>¿Ya te registraste?</h2>
                  </div>
                  <div class='mdl-card__supporting-text mdl-cell--12-col'>
                    <form action='./'  onSubmit='return validarPasswd()' method='post'>
                      <input type='hidden' name='contenido' value='validar_usuario'>

                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' value='$correo' name='correo'  type='email' required>
                        <label class='mdl-textfield__label' for='correo'>CORREO</label>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id='nombres' class='mdl-textfield__input' value='$nombres' id='nombres' name='nombres'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='nombres'>NOMBRES</label>
                        <div class='mdl-tooltip' for='nombres'>
                          solo letras y espacios
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='apellidos' class='mdl-textfield__input' value='$apellidos' name='apellidos'  type='text' pattern='[A-Z,a-z, ]*' required>
                        <label class='mdl-textfield__label' for='apellidos'>APELLIDOS</label>
                        <div class='mdl-tooltip' for='apellidos'>
                          solo letras y espacios
                        </div>
                      </div>";
                      if ($clave1 <> $clave2) {
                        #mensaje contraseña no coinciden
                        $mensaje_contraseña = "HACER COINDIR LAS CONTRASEÑAS";
                        $clave1 = NULL;
                        $clave2 = NULL;
                      }else{
                        $mensaje_contraseña = "CREAR CONTRASEÑA";
                      }

                      echo"
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword1' pattern='.{8,}' value='$clave1' class='mdl-textfield__input' name='pass1'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword1'>$mensaje_contraseña</label>
                        <div class='mdl-tooltip' for='pssword1'>
                          mínimo 8 caracteres
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword2' pattern='.{8,}' value='$clave2'  class='mdl-textfield__input' name='pass2'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword2'>CONFIRMAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword2'>
                          deben coincidir ambas contraseñas
                        </div>
                      </div>
                      <script src='./recursos/guiones/04-mensajes.js'></script>


                      ";
                       dsp_crypt(0,1);
                  echo " 
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input class='mdl-textfield__input' name='codigo'  type='text' id='codigo' required>
                        <label class='mdl-textfield__label' for='codigo'>ESCRIBE EL TEXTO</label>
                        <div class='mdl-tooltip' for='codigo'>
                          los caracteres deben coincidir <br> con los de la imagen
                        </div>
                        <script language='JavaScript'>
                         validaRequerido( 'codigo' );
                       </script>
                      </div>
                    <center>    
                      <input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='CREAR CUENTA'>
                    </center>
                    </form>
                  </div>
        	</div>
        	<div class='mdl-layout-spacer'></div>

        </div>
      </div>       



";


    }
  }


?>