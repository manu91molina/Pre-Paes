<?
?>
<!doctype html>
<!--
  Material Design Lite
  Copyright 2015 Google Inc. All rights reserved.

  Licensed under the Apache License, Version 2.0 (the 'License');
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at

      https://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an 'AS IS' BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License
-->
<html lang='es'>
  <head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='description' content='A front-end template that helps you build fast, modern mobile web apps.'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title><? actualizar_datos_usuario (); if ($_SESSION["nombres"]) {echo $_SESSION["nombres"];}else{echo "Test PRE-PAES";};?></title>

    <!-- Add to homescreen for Chrome on Android -->
    <meta name='mobile-web-app-capable' content='yes'>
    <link rel='shortc icon' href='./recursos/logo_tpp.ico'/>

    <!-- Add to homescreen for Safari on iOS -->
    <meta name='apple-mobile-web-app-capable' content='yes'>
    <meta name='apple-mobile-web-app-status-bar-style' content='black'>
    <meta name='apple-mobile-web-app-title' content='Material Design Lite'>

    <!-- Tile icon for Win8 (144x144 + tile color) -->
    <meta name='msapplication-TileColor' content='#3372DF'>

    <!-- SEO: If your mobile URL is different from the desktop URL, add a canonical link to the desktop page https://developers.google.com/webmasters/smartphone-sites/feature-phones -->
    <!--
    <link rel='canonical' href='http://www.example.com/'>
    -->

    <link href='https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>
    <link rel='stylesheet' href='./recursos/material.min.css'>
    <link rel='stylesheet' href='./recursos/styles.css'>
    <link rel='stylesheet' href='./recursos/styles_android.css'>
    <link rel='stylesheet' href='./recursos/painter_materia.css'>
   
        <script type='text/javascript' src='./recursos/guiones/01-jquery-1.2.6.min.js'></script>
        <script src="https://code.getmdl.io/1.1.3/material.min.js"></script>
        <script type='text/javascript' src='./recursos/guiones/02-jquery-impromptu.1.7.js'></script>
        <script type='text/javascript' src='./recursos/guiones/03-mensajes.js'></script>
    <style>
    #view-source {
      position: fixed;
      display: block;
      right: 0;
      bottom: 0;
      margin-right: 40px;
      margin-bottom: 40px;
      z-index: 900;
    }
    </style>
    <!--barra de progreso-->
    <script>
      document.querySelector('#p1').addEventListener('mdl-componentupgraded', function() {
        this.MaterialProgress.setProgress(10);
      });}
    </script>
  </head>