<?
?>
            <footer class='mdl-mini-footer'>
              <div class='mdl-mini-footer__left-section'>
                <div class='mdl-logo'>
                  <p>Copyleft test paes 2016
                    <div id="tt1" class="icon material-icons">contact_mail</div>
                    <div class="mdl-tooltip" for="tt1">
                    Desarrollador Manuel Molina
                    manuel.ntonio@gmail.com
                    </div>
                    <a href="https://plus.google.com/u/0/+manumolina_mint/" class="android-link material-icons mdl-badge" data-badge="G+" target="_blank">public</a>
                  </p>
                </div>
              </div>
            </footer>

      </main>
    </div>


    <script src='./recursos/material.min.js'></script>
    <script src='./recursos/easypiechart.min.js'></script>
    <script src='./recursos/easypiechart.js'></script>
  </body>
</html>
 
