<?
echo "<body>";
echo "<div class='demo-layout mdl-layout mdl-js-layout  mdl-layout--fixed-header'>";
# aquí introducimos el menu-panel
include "./estructura/menu.php";
echo "<main class='mdl-layout__content mdl-color--grey-100'>";
# verificar si existe usuario admin
$vector_de_usuarios = consultar("select * from usuario;");
$cantidada_de_usuarios = count( $vector_de_usuarios );

$contenido  = @ $_REQUEST['contenido'];
$calificar  = @ $_REQUEST['calificar'];
$calificar_sesion  = @ $_REQUEST['calificar_sesion'];
if ($cantidada_de_usuarios) {
		switch ($contenido){
							# demo test
		                    case "demo_test":
		                    if (!$calificar) {
		                    	include "./aplicaciones/demo_test.php";
		                    }else{
		                    	include "./aplicaciones/calificacion.php";;
		                    }
		                    break;
							# test en sesion
		                    case "test_sesion":
		                    if (!$calificar_sesion) {
		                    	include "./aplicaciones/hacer_test.php";
		                    }else{
		                    	include "./aplicaciones/calificacion_sesion.php";;
		                    }
		                    break;
		                    #usuario solicita crear cuenta
		                    case "registrarme":
		                        include "./aplicaciones/registrar_usuario.php";
		                    break;
		                    case "validar_usuario":
		                        include "./aplicaciones/validando_usuario.php";
		                    break;
		                    #creando cuenta de usuario que realizó test de prueba
		                    case "creando_cuenta":
		                        include "./aplicaciones/registrando_usuario.php";
		                    break;
		                    #ver top promedios
		                    case "top_promedios":
		                    	if (isset( $_SESSION['idusuario'])) {
		                    		include "./aplicaciones/top_promedios.php";
		                    	}else{
		                        	include "./aplicaciones/iniciar_sesion.php";
		                      	}		                        
		                    break;
		                    #ver vitacora de sesiones
		                    case "mis_intentos":
		                    	if (isset( $_SESSION['idusuario'])) {
		                    		include "./aplicaciones/vitacora_de_sesiones.php";
		                    	}else{
		                        	include "./aplicaciones/iniciar_sesion.php";
		                      	}		                    	
		                    break;
		                    #editando cuenta
		                    case "edit_cuenta":
		                    	if ( isset( $_SESSION['correo'] ) ){
		                        	include "./aplicaciones/editar_cuenta.php";
		                        }else{
		                        	include "./aplicaciones/iniciar_sesion.php";
		                        }
		                    break;
		                    #actualizando cuenta
		                    case "actualizando_cuenta":
		                    	if ( isset( $_SESSION['correo'] ) ){
		                        	include "./aplicaciones/actualizando_cuenta.php";
		                        }else{
		                        	include "./aplicaciones/iniciar_sesion.php";
		                        }
		                    break;		                    
		                    default :
		                      if ( isset( $_SESSION['correo'] ) ){
		                        include "./aplicaciones/interfaz_usuario.php";
		                      }else{
		                        include "./aplicaciones/demo_test.php";
		                      }

		                    break;
		}
}else{

	#si no existe ningun usuario, significa que se debe registrar el primer usuario de tipo administrador
	include "./aplicaciones/registrar_admin.php";
}





?>