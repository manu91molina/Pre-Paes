<?

 $hacer_test           = $_REQUEST['contenido'];
 $calificar_sesion  = $_REQUEST['calificar_sesion'];


if ($hacer_test == "test_sesion" && isset($_SESSION['correo']) && !$calificar_sesion ) {
  echo "
      <header class='demo-header mdl-layout__header mdl-color--white mdl-color--white-500 mdl-color-text--grey-600'>
        <div class='mdl-layout__header-row'>
          <span class='mdl-layout-title'><a class='' href='./'><img class='android-logo-image' src='./images/logouls.png'></a></span>
          <div class='mdl-textfield  mdl-textfield--align-right'>
            <span id='error' class='material-icons mdl-color-text--green-700 mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='!'>person_pin</span>
            <div class='mdl-color--green-700 mdl-tooltip' for='error'>
                  Estas en sesión de TEST
            </div>
          </div>
        </div>

      </header>
  ";
}elseif ($calificar_sesion == "calificar_sesion" && isset($_SESSION['correo'])) {
  echo "
      <header class='demo-header mdl-layout__header mdl-color--white mdl-color--white-500 mdl-color-text--cyan-700'>
        <div class='mdl-layout__header-row'>
          <span class='mdl-layout-title'><a class='' href='./'><img class='android-logo-image' src='./images/logouls.png'></a></span>
          <div class='mdl-textfield  mdl-textfield--align-right'>
            <span id='error' class='material-icons mdl-color-text--cyan-700 mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='!'>person_pin</span>
            <div class='mdl-color--cyan-700 mdl-tooltip' for='error'>
                  Test finalizado
            </div>
          </div>
        </div>

      </header>
  ";
}else{
echo "
      <!--menu-->
      <header class='demo-header mdl-layout__header mdl-color--white mdl-color--white-500 mdl-color-text--grey-600'>
        <div class='mdl-layout__header-row'>
          <span class='mdl-layout-title'> <a class='' href='./'><img class='android-logo-image' src='./images/logouls.png'></a></span>
        </div>
      </header>
      <!--  cierre menu-->

";
}
?>

<?

        if ($_SESSION['nombres']) {
          $mdl_color       = "green-700";
          $img_user         = "<img src='./images/user-adm.png' class='demo-avatar'>";
          $nombre_user      = $_SESSION["nombres"];
          $arrow_drop_down  = "
            <button id='accbtn' class='mdl-button mdl-js-button mdl-js-ripple-effect mdl-button--icon'>
              <i class='material-icons' role='presentation'>arrow_drop_down</i>
              <span class='visuallyhidden'>Accounts</span>
            </button>
            <ul class='mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect' for='accbtn'>
              <form method='post' action='./'>
              <li><button name='contenido' value='cerrarsesion' class='mdl-menu__item mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>directions_run</i> CERRAR SESIÓN </button></li>
              <li><button name='contenido' value='edit_cuenta' class='mdl-menu__item mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>settings</i> MODIFIC. CUENTA</button></li>
              </form>
            </ul>";
          $opciones_menu    = "
        <nav class='demo-navigation  mdl-navigation mdl-color--white mdl-color-text--green-700'>
         <form method='post' action='./'>
          <center><button name='contenido' value='' class='mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>home</i></button></center>
          <br/>
          <button name='contenido' value='top_promedios' class='mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>supervisor_account</i> TOP PROMEDIO</button>
          <button name='contenido' value='mis_intentos' class='mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>timeline</i> HISTORIAL</button>

          <div class='mdl-layout-spacer'></div>
         </form>
        </nav>

          ";
        }else{
          $mdl_color       = "cyan";
          $img_user         = "<img src='./images/log_user.png' class='demo-avatar'>";
          $nombre_user      = "INICIAR SESIÓN";
          #$arrow_drop_down  = "<i class='material-icons' role='presentation'>expand_more</i>";
          $opciones_menu    = "
        <nav class='demo-navigation  mdl-navigation mdl-color--white mdl-color-text--cyan-700'>
          <div class='mdl-textfield mdl-cell--12-col mdl-js-textfield mdl-textfield--floating-label'>
            <form method='post' action='./'>     
            <input class='mdl-textfield__input' name='correo'  type='email'>
            <label class='mdl-textfield__label' for='correo'>CORREO</label>
          </div>

          <div class='mdl-textfield mdl-cell--12-col mdl-js-textfield mdl-textfield--floating-label'>
            <input class='mdl-textfield__input' name='pass'  type='password'>
            <label class='mdl-textfield__label' for='pssword1'>CONTRASEÑA</label>
          </div>

          <button name='contenido' value='iniciar' class='mdl-color-text--cyan mdl-button mdl-js-button mdl-js-ripple-effect'>INICIAR</button>
          <br><br>
          </form>
          <div class='mdl-layout-spacer'></div>
          <div class='mdl-card__actions mdl-card--border'>
            <form method='post' action='./'> 
              <button name='contenido' value='registrarme' class='mdl-color-text--cyan mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--cyan material-icons' role='presentation'>assignment_ind</i>¿CREAR UNA CUENTA?</button>
            </form>
          </div>

          <div class='mdl-layout-spacer'></div>

          <a class='mdl-navigation__link' href=''><i class='mdl-color-text--blue-grey-400 material-icons' role='presentation'>help_outline</i><span class='visuallyhidden'>Help</span></a>
        </nav>
          ";
        }

#imprimir menu
  echo "
      <div class='demo-drawer mdl-layout__drawer mdl-color--$mdl_color mdl-color-text--white'>
        <header class='demo-drawer-header'>
         $img_user
          <div class='demo-avatar-dropdown'>
            <span>$nombre_user</span>
            <div class='mdl-layout-spacer'></div>
            $arrow_drop_down
          </div>
        </header>
        $opciones_menu
      </div>

  ";
?>