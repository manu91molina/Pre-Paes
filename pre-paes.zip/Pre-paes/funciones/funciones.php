<?
function head () {
	include "./estructura/head.php";
}

function menu () {
	include "./estructura/menu.php";
}

function body () {
  include "./estructura/body.php";
}

function cierre_body () {
	include "./estructura/cierre_body.php";
}


function mostrar_referencias ($respuestas_malas){

  $cantidad_respuestas_malas = count($respuestas_malas);
  for ($i=0; $i < $cantidad_respuestas_malas; $i++) {
     $idask_mala     = $respuestas_malas[$i];
    
    $vector_temario =
    consultar(
      "SELECT
		    a.idask,
        a.tema_idtema,
        b.tematica,
        b.referencia,
        b.libro_autor
      FROM
        ask as a,
        tema as b
      WHERE
        b.idtema = a.tema_idtema and
        idask = '$idask_mala';");
	ver_referencia ($vector_temario);
  }

 
}

function ver_referencia ($vector_temario){

      for ( $contador = 0 ; $contador < 1; $contador ++ ) {
		    $idask       = $vector_temario[$contador]['idask'];
        $idtema      = $vector_temario[$contador]['tema_idtema'];
        $tematica    = $vector_temario[$contador]['tematica'];
        $referencia  = $vector_temario[$contador]['referencia'];
        $libro_autor = $vector_temario[$contador]['libro_autor'];
        $tematica    = htmlspecialchars_decode($tematica);
        $libro_autor = htmlspecialchars_decode($libro_autor);
        $referencia = explode(" ","$referencia");
        $enlace1 = $referencia[0];
        $enlace2 = $referencia [1];

echo "<p class='mdl-list__item-primary-content'>";

if ($tematica){echo "<i class='material-icons'>search</i>$tematica ";}
 if ($libro_autor){echo "<i class='material-icons'>local_library</i>$libro_autor ";}
if ($enlace1){echo "<i class='material-icons'>link</i><a href='$enlace1' >$enlace1</a> ";}
if ($enlace2){echo "<i class='material-icons'>link</i>$enlace2 ";}
echo " </p>";

      }

}



                function boton_siguiente ($ask_vista){
                 echo " <!-- Accent-colored raised button with ripple -->
                  <button name='ask_vista' value='"; 
                  switch ($ask_vista) {
                    case '1':
                      echo "2";
                      break;
                    case '2':
                      echo "3";
                      break;
                    case '3':
                      echo "4";
                      break;
                    case '4':
                      echo "5";
                      break;
                    case '5':
                      echo "6";
                      break;
                    case '6':
                      echo "7";
                      break;
                    case '7':
                      echo "8";
                      break;
                    case '8':
                      echo "9";
                      break;
                    case '9':
                      echo "10";
                      break;

                    #editado para evaluacion de 10 preguntas#
                    case '10':                              #
                      echo "1";                             #
                    #########################################
                      break;
                    case '11':
                      echo "12";
                      break;
                    case '12':
                      echo "13";
                      break;
                    case '13':
                      echo "14";
                      break;
                    case '14':
                      echo "15";
                      break;
                    case '15':
                      echo "16";
                      break;
                    case '16':
                      echo "17";
                      break;
                    case '17':
                      echo "18";
                      break;
                    case '18':
                      echo "19";
                      break;
                    case '19':
                      echo "20";
                      break;
                    case '20':
                      echo "21";
                      break;
                    case '21':
                      echo "22";
                      break;
                    case '22':
                      echo "23";
                      break;
                    case '23':
                      echo "24";
                      break;
                    case '24':
                      echo "25";
                      break;
                    case '25':
                      echo "1";
                      break;
                    default:
                      echo "2";
                      break;
                  }
                  echo"' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>
                    SIGUIENTE
                  </button>";
                }

function listar_preguntas ($preguntas_materia){

  switch ($preguntas_materia) {
    case 'sociales':
      $materia = 1;
      break;
    case 'matematicas':
      $materia = 2;
      break;
    case 'ciencias':
      $materia = 3;
      break;
    case 'lenguaje':
      $materia = 4;
      break;   
    default:
      # code...
      break;
  }
    $vector_ask = consultar("select * from ask where materia_idmateria = $materia order by idask;");
    $cantidad_ask = count( $vector_ask );
    if ( $cantidad_ask > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_ask; $contador ++ ) {
        $idask      = $vector_ask[$contador]['idask'];
        $idtema     = $vector_ask[$contador]['tema_idtema'];
        $idmateria  = $vector_ask[$contador]['materia_idmateria'];
        $ask        = $vector_ask[$contador]['pregunta'];
        $img        = $vector_ask[$contador]['img'];
        $ask    = mostrar_comilla_simple_ask ($ask);
        $ask    = str_replace("\r","<br>",$ask);
        $ask    = recortar_ask ($ask,80);
        #$ask = utf8_decode($ask);
        echo "<tr>";
        echo    "<th>";
        echo      $indice = 1 + $contador;
        echo    "</th>";
        echo    "<td class='mdl-data-table__cell--non-numeric'>";
        echo      "$ask";
        echo    "</td>";
        echo    "<td>";
        echo      "<form method='post' action='./' enctype='multipart/form-data'>
                   <input type='hidden' name='materia' value='$preguntas_materia'>";
        echo      "<input type='hidden' name='edit_idask' value='$idask'>";
        echo      "<button type='submit' name='contenido' value='guardar_edit_ask' class='mdl-button mdl-js-button mdl-button--icon mdl-button--colored'>";
        echo        "<i class='material-icons'>visibility</i>";
        echo      "</button>";
        echo      "</form>";
        echo    "</td>";
        echo    "<td>";
        echo      "<form method='post' action='./' enctype='multipart/form-data'>";
        echo      "<input type='hidden' name='materia' value='$preguntas_materia'>";
        echo      "<input type='hidden' name='idask' value='$idask'>";
        echo      "<input type='hidden' name='img' value='$img'>";
        echo      "<button type='submit' name='contenido' value='$preguntas_materia' class='mdl-button mdl-js-button mdl-button--icon mdl-button--colored'>";
        echo        "<i class='material-icons'>edit</i>";
        echo      "</button>";
        echo      "</form>";
        echo    "</td>";
        echo "</tr>";
      }
    }  
}



function nombre_materia ($preguntas_materia){
    switch ($preguntas_materia) {
    case 'sociales':
      echo  "Estudios Sociales";
      break;
    case 'matematicas':
      echo  "Matemáticas";
      break;
    case 'ciencias':
      echo "Ciencia Naturales";
      break;
    case 'lenguaje':
      echo "Lenguaje y Literatura";
      break;   
    default:
      # code...
      break;
  }
}

function materia ($materia){
    switch ($materia) {
    case 'sociales':
      echo  "Estudios Sociales";
      break;
    case 'matematicas':
      echo  "Matemáticas";
      break;
    case 'ciencias':
      echo "Ciencia Naturales";
      break;
    case 'lenguaje':
      echo "Lenguaje y Literatura";
      break;   
    default:
      # code...
      break;
  }
}

function ask ($idask){
    $vector_ask = consultar("select * from ask where idask = $idask;");
    $cantidad_ask = count( $vector_ask );
    if ( $cantidad_ask > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_ask; $contador ++ ) {
        $idask      = $vector_ask[$contador]['idask'];
        $idtema     = $vector_ask[$contador]['tema_idtema'];
        $idmateria  = $vector_ask[$contador]['materia_idmateria'];
        $ask        = $vector_ask[$contador]['pregunta'];
        $img        = $vector_ask[$contador]['img'];
        $ask    = mostrar_comilla_simple_ask ($ask);
        #$ask    = str_replace("\r","<br>",$ask);
        echo "$ask";
      }
    }
}

### mostrar mejor nota en materia de x usuario ##########
function mejor_nota_materia ($idmateria, $idusuario) {
    $vector_nota_materia = consultar("select * from historial_sesiones where usuario_idusuario = $idusuario and materia_idmateria = $idmateria order by nota_final, fecha desc, hora desc;");
    $cantidad_nota = 1;
    if ( $cantidad_nota == 1 ) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $fecha      = $vector_nota_materia[$contador]['fecha'];
        $hora       = $vector_nota_materia[$contador]['hora'];
        $nota_final = $vector_nota_materia[$contador]['nota_final'];
        
        echo "<center><h1>$nota_final</h1></center>";

        if (fecha and $hora) {
          echo date("d F 'y", strtotime("$fecha"))." ".date('h:i a', strtotime("$hora"))."";
        }



        }
    }
}

############# boton para filtrar vitacora de sesiones de una materia #########
function ver_vitacora_materia (){
    $vector_materias = consultar("select * from materia;");
    $cantidad_materias = count( $vector_materias );
    if ( $cantidad_materias > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_materias; $contador ++ ) {
        $idmateria = $vector_materias[$contador]['idmateria'];
        $materia   = $vector_materias[$contador]['materia' ];        
        
        echo"<li><center><button name='idmateria' value='$idmateria' class='mdl-color-text--green-700 mdl-button mdl-js-button mdl-js-ripple-effect'>$materia</button></center></li>";
        
      }
    }
}




function mostrar_promedio ($idusuario){
    $vector_promedio = consultar("select * from historial_promedios where usuario_idusuario = $idusuario;");
    $cantidad_promedio = count($vector_promedio);

    for ( $contador = 0 ; $contador < $cantidad_promedio; $contador ++ ) {
      $promedio = $vector_promedio[$contador]['promedio'];
      echo "<center><h1>$promedio</h1></center>";
    }

}

function actualizando_promedio ($idusuario){
    $vector_materia_1 = consultar("select * from historial_sesiones where usuario_idusuario = $idusuario and materia_idmateria = 1 order by nota_final, fecha desc, hora desc;");
    $cantidad_nota = 1;
    if ( $cantidad_nota == 1 ) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $nota_final_1 = $vector_materia_1[$contador]['nota_final'];
      }
    }
    $vector_materia_2 = consultar("select * from historial_sesiones where usuario_idusuario = $idusuario and materia_idmateria = 2 order by nota_final, fecha desc, hora desc;");
    $cantidad_nota = 1;
    if ( $cantidad_nota == 1 ) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $nota_final_2 = $vector_materia_2[$contador]['nota_final'];
      }
    }
    $vector_materia_3 = consultar("select * from historial_sesiones where usuario_idusuario = $idusuario and materia_idmateria = 3 order by nota_final, fecha desc, hora desc;");
    $cantidad_nota = 1;
    if ( $cantidad_nota == 1 ) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $nota_final_3 = $vector_materia_3[$contador]['nota_final'];
      }
    }
    $vector_materia_4 = consultar("select * from historial_sesiones where usuario_idusuario = $idusuario and materia_idmateria = 4 order by nota_final, fecha desc, hora desc;");
    $cantidad_nota = 1;
    if ( $cantidad_nota == 1 ) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $nota_final_4 = $vector_materia_4[$contador]['nota_final'];
      }
    }

    ##formula para calcular promedio ###
    $NOTA_BASE      = 10;
    $cantidad_notas = 4;
    $suma_notas     = $nota_final_1 + $nota_final_2 + $nota_final_3 + $nota_final_4;
    $promedio       = ($suma_notas / $cantidad_notas) * $NOTA_BASE;
    ########################## 


    ### encontrar si usuario esta en el historial #########
    $fecha         = date("d-m-Y");
    $hora          = date ("H:i:s");

    $vector_usuario_promedio = consultar("select * from historial_promedios where usuario_idusuario = $idusuario;");
    $cantidad_usuario = count($vector_usuario_promedio);

    for ( $contador = 0 ; $contador < $cantidad_usuario; $contador ++ ) {
      $usuario_idusuario = $vector_usuario_promedio[$contador]['usuario_idusuario'];
    }

    if ($usuario_idusuario) {
        $sql="
          UPDATE
            historial_promedios 
            SET
              fecha = '$fecha',
              hora   = '$hora',
              promedio = '$promedio'
            WHERE 
              usuario_idusuario ='$usuario_idusuario';";
        #ejecutar sql
        $resultado = ejecutar( $sql );
    }else{
      ############# INSERTAR EL PROMEDIO ######################
      $sql="
      INSERT INTO historial_promedios (usuario_idusuario, fecha, hora, promedio)
      VALUES ('$idusuario', '$fecha', '$hora', '$promedio');";
      #ejecutar sql
      $registrado = ejecutar( $sql );  
    }


}



#### filtrar los mejores promedios entre usuarios ####################

function top_promedio (){

  $vector_promedios = consultar("select * from top_promedio ;");
  $cantidad_top = count($vector_promedios);
  ## cantidad de usuarios a mostrar en el top#
  if ($cantidad_top < 20) {
    $top = $cantidad_top;
  }else{
    #si existen mas de 10 promedios registrados mostrar los mejores 20
    $top = 20;
  }

    for ( $contador = 0 ; $contador < $top; $contador ++ ) {
      $idusuario = $vector_promedios[$contador]['usuario_idusuario'];
      $nombres   = $vector_promedios[$contador]['nombres'];
      $apellidos = $vector_promedios[$contador]['apellidos'];
      $instituto = $vector_promedios[$contador]['instituto'];
      $fecha     = $vector_promedios[$contador]['fecha'];
      $hora      = $vector_promedios[$contador]['hora'];
      $promedio  = $vector_promedios[$contador]['promedio'];

      $fecha = date("d F 'y", strtotime("$fecha"))."";
      $hora  = date('h:i a', strtotime("$hora"))."";

      echo "
                  <li class='mdl-list__item mdl-list__item--three-line'>
                    <span class='mdl-list__item-primary-content'>
                      <i class='material-icons mdl-list__item-avatar'>person</i>
                      <span>$nombres $apellidos</span>
                      <span class='mdl-list__item-text-body'>
      ";
                      if (!$instituto) {
                        # 
                      }else{
                        echo "
                        <em><small>$instituto</small></em></br>
                        ";
                      }
      echo "
                         Notas: "; mejor_nota ($idusuario); echo"  Útima Actividad: <em><i class='mdl-color-text--green-A700 material-icons'>date_range</i> $fecha <i class='mdl-color-text--green-A700 material-icons'>watch_later</i>$hora</em>
                      </span>
                    </span>
                    <span class='mdl-list__item-secondary-content'>
                      <sapn class='mdl-list__item-secondary-action' href='#'><h4>$promedio</h4></sapn>
                    </span>
                  </li>
      ";


    }
}

function mejor_nota ($idusuario){
    $vector_nota_materia = consultar("SELECT * FROM mejores_notas_cada_materia WHERE usuario_idusuario = $idusuario;");
    $cantidad_nota = count($vector_nota_materia);
    if ( $cantidad_nota > 0) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $materia       = $vector_nota_materia[$contador]['materia'];
        $nota_final    = $vector_nota_materia[$contador]['nota_final'];
        #$fecha_nota         = $vector_nota_materia[$contador]['fecha'];

        #$fecha_nota = date("d F 'y", strtotime("$fecha_nota"))."";
        
        echo "<b>$materia $nota_final | </b> ";

        }
    }
}


function vitacora_sesiones_general (){
    $idusuario = $_SESSION["idusuario"];
    $vector_nota_materia = consultar("SELECT * FROM vitacora_resultados_en_sesiones WHERE usuario_idusuario = $idusuario;");
    $cantidad_nota = count($vector_nota_materia);
    if ( $cantidad_nota > 0) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $materia              = $vector_nota_materia[$contador]['materia'];
        $fecha_nota           = $vector_nota_materia[$contador]['fecha'];
        $hora_nota            = $vector_nota_materia[$contador]['hora'];
        $respuestas_acertadas = $vector_nota_materia[$contador]['respuestas_acertadas'];
        $respuestas_erroneas  = $vector_nota_materia[$contador]['respuestas_erroneas'];
        $nota_final           = $vector_nota_materia[$contador]['nota_final'];

        $fecha_nota = date("d F 'y", strtotime("$fecha_nota"))."";
        $hora_nota  = date('h:i a', strtotime("$hora_nota"))."";

        
        echo "
            <tr>
              <td><h6><center>$materia</center></h6></td>            
              <td><h6><center>$fecha_nota</center></h6></td>
              <td><h6>$hora_nota</h6></td>
              <td><h6><center>$respuestas_acertadas</center></h6></td>
              <td><h6><center>$respuestas_erroneas</center></h6></td>
              <td><h6><center>$nota_final</center></h6></td>
            </tr>
        ";

        }
    }
}


function vitacora_sesiones_materia ($idmateria, $mes){
    $idusuario = $_SESSION["idusuario"];
    if ($mes && $idmateria) {
      #echo "ambas";
      $vector_nota_materia = consultar("SELECT * FROM vitacora_resultados_en_sesiones WHERE usuario_idusuario = $idusuario and  TO_CHAR(fecha,'YYYY-MM')='$mes' and materia_idmateria = $idmateria;");
    }elseif ($mes || $idmateria) {
      #echo "uno de dos";
        if ($mes) {
          $vector_nota_materia = consultar("SELECT * FROM vitacora_resultados_en_sesiones WHERE usuario_idusuario = $idusuario and TO_CHAR(fecha,'YYYY-MM')='$mes';");
        }elseif ($idmateria) {
          $vector_nota_materia = consultar("SELECT * FROM vitacora_resultados_en_sesiones WHERE usuario_idusuario = $idusuario and materia_idmateria = $idmateria;");
        }
    }else{
      #echo "ninguna";
      $vector_nota_materia = consultar("SELECT * FROM vitacora_resultados_en_sesiones WHERE usuario_idusuario = $idusuario;");
    }
    
    
    #cantidad de sesiones a mostrar
    $cantidad_nota_bd = count($vector_nota_materia);
    if ($cantidad_nota_bd < 20) {
      $cantidad_nota = $cantidad_nota_bd;
    }else{
      $cantidad_nota = 20;
    }

    
    if ( $cantidad_nota > 0) {
      for ( $contador = 0 ; $contador < $cantidad_nota; $contador ++ ) {
        $materia              = $vector_nota_materia[$contador]['materia'];
        $fecha_nota           = $vector_nota_materia[$contador]['fecha'];
        $hora_nota            = $vector_nota_materia[$contador]['hora'];
        $respuestas_acertadas = $vector_nota_materia[$contador]['respuestas_acertadas'];
        $respuestas_erroneas  = $vector_nota_materia[$contador]['respuestas_erroneas'];
        $nota_final           = $vector_nota_materia[$contador]['nota_final'];

        $fecha_nota = date("d F 'y", strtotime("$fecha_nota"))."";
        $hora_nota  = date('h:i a', strtotime("$hora_nota"))."";

        
        echo "
            <tr>
              <td><h6><center>$materia</center></h6></td>
              <td><h6><center>$nota_final</center></h6></td>            
              <td><h6><center>$fecha_nota</center></h6></td>
              <td><h6>$hora_nota</h6></td>
              <td><h6><center>$respuestas_acertadas</center></h6></td>
              <td><h6><center>$respuestas_erroneas</center></h6></td>

            </tr>
        ";

        }
    }
}

function ask_con_img ($idask){
    $vector_ask_adjunto = consultar("SELECT * FROM ask WHERE idask = $idask;");
    $cantidad_ask_adjunto = count( $vector_ask_adjunto );
    if ( $cantidad_ask_adjunto > 0 ) {
      for ( $contador = 0 ; $contador <= $cantidad_ask_adjunto; $contador ++ ) {
        $idask      = $vector_ask_adjunto[$contador]['idask'];
        $idtema     = $vector_ask_adjunto[$contador]['tema_idtema'];
        $idmateria  = $vector_ask_adjunto[$contador]['materia_idmateria'];
        $ask        = $vector_ask_adjunto[$contador]['pregunta'];
        $imagen     = $vector_ask_adjunto[$contador]['img'];
        $ask    = mostrar_comilla_simple_ask ($ask);
        $ask    = str_replace("\r","<br>",$ask);      
        
        echo "$ask";
        if ($imagen == "ninguna") {
          # nada...
        }else{
          echo "</br><center><img class='ilustracion'  src='$imagen' alt='' /></center>";
          echo "<input type='hidden' name='img' value='$imagen'>";
        }
      }
    }
}


###### funcion que recorta caracteres de pregunta ########

function recortar_ask($ask, $numero){ 
  if(strlen($ask) > $numero){ 
    $ask=substr($ask,0,$numero)."<i class='material-icons'>more_horiz</i>";
    #$ask = str_replace("&amp;#39", "'", $ask);
     }else{ 
      $ask=$ask;
      #$ask = str_replace("&amp;#39", "'", $ask);
     } 
        return $ask; 
}

# esta funcion edita una pregunta sin aadjuntar imagen y sin anular imagen
function editando_pregunta ($idask, $ask, $tema, $libro, $enlace1, $enlace2){ 
    $ask= permitir_comilla_simple_ask ($ask);
    echo "$idask, $ask, $tema, $libro <br>";
    echo $referencia = "$enlace1 | $enlace2";

    $vector_tema = consultar("select * from tema where tematica = '$tema' and referencia = '$referencia' and libro_autor = '$libro';");
    echo $cantidad_tema = count( $vector_tema );
    if ( $cantidad_tema > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_tema; $contador ++ ) {
        $idtema      = $vector_tema[$contador]['idtema'];
      }

        $sql="
          UPDATE
            ask 
            SET
              tema_idtema = '$idtema',
              pregunta   = '{$ask}'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );

    }else{
        $sql="
          INSERT INTO 
            tema (tematica, referencia, libro_autor)
            VALUES ('$tema', '$referencia', '$libro');";
        $resultado = ejecutar( $sql );
        $vector_tema = consultar("select * from tema where tematica = '$tema' and referencia= '$referencia' and libro_autor= '$libro';");
        $cantidad_tema = count( $vector_tema );
        if ( $cantidad_tema > 0 ) {
          for ( $contador = 0 ; $contador < $cantidad_tema; $contador ++ ) {
            $idtema      = $vector_tema[$contador]['idtema'];
          }
        }

        $sql="
          UPDATE
            ask 
            SET
              tema_idtema = '$idtema',
              pregunta   = '{$ask}'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );
        
    }
}



# esta funcion edita una pregunta sin aadjuntar imagen pero con anular imagen
function editando_ask_anular_imagen ($idask, $ask, $anular_img, $tema, $libro, $enlace1, $enlace2){ 
 
    $ask= permitir_comilla_simple_ask ($ask);
    echo "$idask, $ask, $anular_img, $tema, $libro <br>";
    echo $referencia = "$enlace1 | $enlace2";

    $vector_tema = consultar("select * from tema where tematica = '$tema' and referencia = '$referencia' and libro_autor = '$libro';");
    $cantidad_tema = count( $vector_tema );
    if ( $cantidad_tema > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_tema; $contador ++ ) {
        $idtema      = $vector_tema[$contador]['idtema'];
      }

      if ($anular_img) {
        $sql="
          UPDATE
            ask 
            SET
              tema_idtema = '$idtema',
              pregunta   = '{$ask}',
              img        = 'ninguna'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );
      }else{
        $sql="
          UPDATE
            ask 
            SET
              tema_idtema = '$idtema',
              pregunta   = '{$ask}'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );
      }


    }else{
        $sql="
          INSERT INTO 
            tema (tematica, referencia, libro_autor)
            VALUES ('$tema', '$referencia', '$libro');";
        $resultado = ejecutar( $sql );
        $vector_tema = consultar("select * from tema where tematica = '$tema' and referencia= '$referencia' and libro_autor= '$libro';");
        $cantidad_tema = count( $vector_tema );
        if ( $cantidad_tema > 0 ) {
          for ( $contador = 0 ; $contador < $cantidad_tema; $contador ++ ) {
            $idtema      = $vector_tema[$contador]['idtema'];
          }
        }

        $sql="
          UPDATE
            ask 
            SET
              tema_idtema = '$idtema',
              pregunta   = '{$ask}'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );
        
		if ($anular_img) {
			$sql="
			  UPDATE
				ask 
				SET
				  img        = 'ninguna'
				WHERE 
				  idask ='$idask';";
			#ejecutar sql
			$resultado = ejecutar( $sql );
		}
        
    }
}


# editar pregunta con imagen adjuntada
function editando_ask_img ($idask, $ask, $imagen, $tipo_imagen, $nombreimagen, $anular_img, $tema, $libro, $enlace1, $enlace2){

      switch ($tipo_imagen) {
        case 'image/jpeg':
          $nombreimagen=random_name().".jpeg";
          $rutadestino= "../ilustracion/$nombreimagen";
          $rutabasededato = "./ilustracion/$nombreimagen";
          break;
        case 'image/png':
          $nombreimagen=random_name().".png";
          $rutadestino= "../ilustracion/$nombreimagen";
          $rutabasededato = "./ilustracion/$nombreimagen";
          break;
        case 'image/gif':
          $nombreimagen=random_name().".gif";
          $rutadestino= "../ilustracion/$nombreimagen";
          $rutabasededato = "./ilustracion/$nombreimagen";
          break;
        default:
          # code...
          break;
      }

    if(move_uploaded_file($imagen, $rutadestino)){
      $ask= permitir_comilla_simple_ask ($ask);
      editando_ask_anular_imagen ($idask, $ask, $anular_img, $tema, $libro, $enlace1, $enlace2);
          $sql="
            UPDATE
              ask 
              SET
                pregunta   = '{$ask}',
                img        = '$rutabasededato'
              WHERE 
                idask ='$idask';";
          #ejecutar sql
          $resultado = ejecutar( $sql );
    }else{
      echo "Algo malo ocurre :(";
    }
}

#mostrar opciones de cada pregunta en vista
function listar_opciones ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask;");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $idopcion = $vector_opc[$contador]['idopcion'];
        $opcion   = $vector_opc[$contador]['opcion' ];
        $opcion   = mostrar_comilla_simple_ask ($opcion);#
        
        echo"<li class='list-unstyled'>$opcion</li>";
        
      }
    }  
}

############# mostrar opciones de cada pregunta para editar #################################
function a_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'a';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion                  = $vector_opc[$contador]['opcion'];
        $opcion   = mostrar_comilla_simple_ask ($opcion);
        echo "$opcion";
      }
    }  
}

function b_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'b';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        $opcion   = mostrar_comilla_simple_ask ($opcion);
        echo "$opcion";
      }
    }  
}

function c_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'c';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        $opcion   = mostrar_comilla_simple_ask ($opcion);
        echo "$opcion";
      }
    }  
}

function d_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'd';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        $opcion   = mostrar_comilla_simple_ask ($opcion);
        echo "$opcion";
      }
    }  
}

function e_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'e';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        $opcion   = mostrar_comilla_simple_ask ($opcion);
        echo "$opcion";
      }
    }  
}

# funcion para mostrar opcion true en radio button vista previa
function opction_true ($idask, $true){
    $vector_opc_true = consultar("select * from opcion where ask_idask=$idask and truefalse_idtruefalse=2;");
    $cantidad_opc_true = count( $vector_opc_true );
    if ( $cantidad_opc_true > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc_true; $contador ++ ) {
        $literal   = $vector_opc_true[$contador]['literal'];
      }
      if ($literal==$true) {
        echo "checked";
      }else{
        echo "disabled";
      }
    }  
}

# funcion para mostrar opcion true en radio button editar
function opction_true_edit ($idask, $true){
    $vector_opc_true_edit = consultar("select * from opcion where ask_idask=$idask and truefalse_idtruefalse=2;");
    $cantidad_opc_true_edit = count( $vector_opc_true_edit );
    if ( $cantidad_opc_true_edit > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc_true_edit; $contador ++ ) {
        $literal   = $vector_opc_true_edit[$contador]['literal'];
      }
      if ($literal==$true) {
        echo "checked";
      }
    }  
}



# funcion para editar opciones en bd
function editando_opciones ($idask, $opc_a, $opc_b, $opc_c, $opc_d, $opc_e, $options_true){  
    $opc_a= permitir_comilla_simple_ask ($opc_a);
    $opc_b= permitir_comilla_simple_ask ($opc_b);
    $opc_c= permitir_comilla_simple_ask ($opc_c);
    $opc_d= permitir_comilla_simple_ask ($opc_d);
    $opc_e= permitir_comilla_simple_ask ($opc_e);

    $vector_opc = consultar("select * from opcion where ask_idask=$idask;");
    echo $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 && $cantidad_opc <= 5 && $opc_a && $opc_b && $opc_c && $opc_d && $opc_e) {
      switch ($options_true) {
        case 'a':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'd';
            UPDATE opcion SET opcion = '{$opc_e}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'e';              
          ";
          $resultado = ejecutar( $sql );
        break;
        case 'b':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'd';
            UPDATE opcion SET opcion = '{$opc_e}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'e';              
          ";
          $resultado = ejecutar( $sql );
        break;
        case 'c':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'd';
            UPDATE opcion SET opcion = '{$opc_e}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'e';              
          ";
          $resultado = ejecutar( $sql );
        break;
        case 'd':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'd';
            UPDATE opcion SET opcion = '{$opc_e}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'e';              
          ";
          $resultado = ejecutar( $sql );
        break;
        case 'e':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'd';
            UPDATE opcion SET opcion = '{$opc_e}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'e';              
          ";
          $resultado = ejecutar( $sql );
        break;
        default:
        ####
          break;
      }
    }elseif (!$opc_a || !$opc_b || !$opc_c || !$opc_d || !$opc_e) {
      echo "<small class='mdl-badge' data-badge='!'><i>No se pudo actualizar las opciones! llene todas las opciones</i></small>";
    }else{

      switch ($options_true) {
        case 'a':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_e}', 'e', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        case 'b':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_e}', 'e', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        case 'c':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_e}', 'e', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        case 'd':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_d}', 'd', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_e}', 'e', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        case 'e':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_e}', 'e', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break; 
        
        default:
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_e}', 'e', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
      }
    }
}



function permitir_comilla_simple_ask ($ask){
    $ask  = str_replace("'", "&#39", $ask);
    return $ask; 
}

function mostrar_comilla_simple_ask ($ask){
  $ask= str_replace("&amp;#39", "'", $ask);
  return $ask; 
}

function random_name(){

  $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890";
  $cad = "";
  for($i=0;$i<10;$i++) {
      $cad .= substr($str,rand(0,120),1);
  }
  return $cad;
}

function reemplazar_espacio ($literal){
  $literal= str_replace(" ", "", $literal);
  return $literal; 
}

function random_correo(){

  $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890";
  $correo = "";
  for($i=0;$i<8;$i++) {
      $correo .= substr($str,rand(0,120),1);
  }
  return $correo;
}

function correo_admin () {
    $admon = "select * from admon where idadmon=1;";
    $consultar = consultar ( $admon);
    $verficar_existencia = count($consultar);

    if ( $verficar_existencia > 0) {
      for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
          $CORREO_ADMIN   = $consultar[$contador]['correo'];

        }
    }

}


######### funciones para la sesion ##################

function lista_departamentos (){
  echo "
      
        <option value='Ahuchapán'>Ahuchapán</option>
        <option value='Chalatenango'>Chalatenango</option>
        <option value='Cuscatlán'>Cuscatlán</option>
        <option value='Cabañas'>Cabañas</option>
        <option value='La Libertad'>La Libertad</option>
        <option value='La Paz'>La Paz</option>
        <option value='La Unión'>La Unión</option>
        <option value='Morazán'>Morazán</option>
        <option value='Santa Ana'>Santa Ana</option>
        <option value='Sonsonate'>Sonsonate</option>
        <option value='San Salvador'>San Salvador</option>
        <option value='San Vicente'>San Vicente</option>
        <option value='San Miguel'>San Miguel</option>
        <option value='Usulután'>Usulután</option>

  ";
}

function lista_institutos (){

    $institutos = "select * from instituto;";
    $consultar = consultar ( $institutos);
    $verficar_existencia = count($consultar);

    echo "<datalist id='buscar'>";
    if ( $verficar_existencia > 0) {
      for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
          $idinstituto   = $consultar[$contador]['idinstituto'];
          $instituto     = $consultar[$contador]['instituto'];
          echo "<option value='$instituto'>";

        }
    }
    echo "</datalist>";

}

function editar_cuenta (){
  $correo = $_SESSION["correo"] ;
    $datos_cuenta_usuario = "select * from usuario where correo = '$correo';";
    $consultar = consultar ( $datos_cuenta_usuario);
    $verficar_existencia = count($consultar);

    if ( $verficar_existencia > 0) {
      for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
          $id           = $consultar[$contador]['idusuario'];
          $correo       = $consultar[$contador]['correo'];
          $nombres      = $consultar[$contador]['nombres'];
          $apellidos    = $consultar[$contador]['apellidos'];
        }

    echo "

     <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
       <input class='mdl-textfield__input' value='$correo' name='correo'  type='email' required>
       <label class='mdl-textfield__label mdl-color-text--green-600' for='correo'>CORREO</label>
     </div>
     <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
       <input id='nombres' class='mdl-textfield__input' value='$nombres' id='nombres' name='nombres'  type='text' pattern='[A-Z,a-z, ]*' required>
       <label class='mdl-textfield__label mdl-color-text--green-600' for='nombres'>NOMBRES</label>
       <div class='mdl-tooltip' for='nombres'>
         solo letras y espacios
       </div>
     </div>
     <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
       <input id ='apellidos' class='mdl-textfield__input' value='$apellidos' name='apellidos'  type='text' pattern='[A-Z,a-z, ]*' required>
       <label class='mdl-textfield__label mdl-color-text--green-600' for='apellidos'>APELLIDOS</label>
       <div class='mdl-tooltip' for='apellidos'>
         solo letras y espacios
       </div>
     </div>
    " ;

    }


}




function validar_usuario_registrandose($registrado, $correo, $clavemd5) {
  include "./configuraciones/principal.php";

  if ($registrado) {

      $sql = "select * from usuario where pass   = '{$clavemd5}' and correo = '$correo';";
      $consultar = consultar ( $sql);
      $verficar_existencia = count($consultar);  

      if ( $verficar_existencia > 0) {
        for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
            ( $contador + 1 );
            $id       = $consultar[$contador]['idusuario'];
            $correo   = $consultar[$contador]['correo'];
            $nombres  = $consultar[$contador]['nombres'];
            $apellido = $consultar[$contador]['apellidos'];

            $_SESSION["correo"]     = $correo;
            $_SESSION["idusuario"]  = $id;
            $_SESSION["nombres"]    = $nombres;
            $_SESSION["apellidos"]  = $apellidos;
            $resultado = TRUE;
          }
      }else{
        echo "
            <div class='mdl-color--white mdl-layout__header-row'>
              <span id='error' class='material-icons mdl-color-text--cyan mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='i'>perm_identity</span>
                <div class='mdl-color--cyan mdl-tooltip' for='error'>
                  Probablemente introdujo mal su correo o contraseña, <br> intente de nuevo
                </div>
            </div>
          ";
      }
        
  }
    

  if ( $contenido == "cerrarsesion" ) {
      $_SESSION["correo"] = NULL;
      $_SESSION["idusuario"]  = NULL;
      $_SESSION["nombres"] = NULL;
      session_destroy();
    unset( $_SESSION["correo"] );
    unset( $_SESSION["idusuario"] );
    unset( $_SESSION["nombres"] );
  }
}


function actualizar_datos_usuario (){
  $contenido = @ $_REQUEST['contenido'];
  if ($contenido == "actualizando_cuenta") {
      $idusuario = $_SESSION["idusuario"];
      $_SESSION["nombres"] = NULL;
      unset( $_SESSION["nombres"] );
      $_SESSION["apellidos"] = NULL;
      unset( $_SESSION["apellidos"] );

     $sql = "select * from usuario where idusuario = '$idusuario';";
      $consultar = consultar ($sql);
      $verficar_existencia = count($consultar);  

      if ($verficar_existencia > 0) {
        for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
            ( $contador + 1 );
            $nombres  = $consultar[$contador]['nombres'];
            $apellido = $consultar[$contador]['apellidos'];
            
            $_SESSION["nombres"]      = $nombres;
            $_SESSION["apellidos"]    = $apellidos;
            $resultado = TRUE;
          }

      }
  }

}


function validar_usuario() {
  include "./configuraciones/principal.php";
  $contenido = @ $_REQUEST['contenido'];

  if ( $contenido == "iniciar") {
    $correo     =  $_REQUEST['correo'];
    $contraseña  =  $_REQUEST['pass'];
    $contraseña  = md5($contraseña);

     $sql = "select * from usuario where pass = '{$contraseña}' and  correo = '$correo';";
      $consultar = consultar ($sql);
      $verficar_existencia = count($consultar);  

      if ($verficar_existencia > 0) {
        for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
            ( $contador + 1 );
            $id       = $consultar[$contador]['idusuario'];
            $correo   = $consultar[$contador]['correo'];
            $nombres  = $consultar[$contador]['nombres'];
            $apellido = $consultar[$contador]['apellidos'];

            $_SESSION["correo"]    = $correo;
            $_SESSION["idusuario"] = $id;
            $_SESSION["nombres"]   = $nombres;
            $resultado = TRUE;
          }
      }else{
        echo "
            <div class='mdl-color--white mdl-layout__header-row'>
              <span id='error' class='material-icons mdl-color-text--cyan mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='i'>perm_identity</span>
                <div class='mdl-color--cyan mdl-tooltip' for='error'>
                  Probablemente introdujo mal su correo o contrase&ntilde;a, <br> intente de nuevo
                </div>
            </div>
        ";
      }
        
  }
    

  if ( $contenido == "cerrarsesion" ) {
      $_SESSION["correo"] = NULL;
      $_SESSION["idusuario"]  = NULL;
      $_SESSION["nombres"] = NULL;
      session_destroy();
    unset( $_SESSION["correo"] );
    unset( $_SESSION["idusuario"] );
    unset( $_SESSION["nombres"] );
  }
}


 ### BD ####################

  function conectar() {
    include "./configuraciones/principal.php";
    $parametros  = "host='$SERVIDOR_DE_BASE_DE_DATOS' ";
    $parametros .= "port='5432' ";
    $parametros .= "dbname='$BASE_DE_DATOS' ";
    $parametros .= "user='$USUARIO_DE_BASE_DE_DATOS' ";
    $parametros .= "password='$CLAVE_DE_BASE_DE_DATOS'";
    $conexion = @ pg_connect( $parametros );
    if ( !$conexion ) {
      echo "<br>No se pudo establecer la conexi&oacute;n a la base de datos<br>";
    }
    return $conexion;
  };

  function existe_conexion () {
    include "./configuraciones/principal.php";
    $parametros  = "host='$SERVIDOR_DE_BASE_DE_DATOS' ";
    $parametros .= "port='5432' ";
    $parametros .= "dbname='$BASE_DE_DATOS' ";
    $parametros .= "user='$USUARIO_DE_BASE_DE_DATOS' ";
    $parametros .= "password='$CLAVE_DE_BASE_DE_DATOS'";
    $conexion = @ pg_connect( $parametros );
    if ( $conexion ) {
      $resultado = TRUE;
      pg_close( $conexion );
    } else {
      $resultado = FALSE;
    }
    return $resultado;
  }

  function consultar( $sql ){
    $conexion = conectar();
    $resultado = array();
    if ( $conexion ) {
      $consulta = @ pg_query( $conexion, $sql );
      if ( $consulta ) {
        while ( $fila = pg_fetch_array( $consulta ) ) {
            $resultado[] = $fila;
        }
      } else {
        # Esta parte la hice para depurado, comentar esta linea si no se desea ver los resultados
       echo "<br>No se ejecuto la sentencia <br><pre> $sql</pre> <br>";
      }
    } else {
      echo "<br>No hay conexi&oacute;n<br>";
    }
    return $resultado;
  }

  function consultar2( $sql2 ){
    $conexion = conectar();
    $resultado = array();
    if ( $conexion ) {
      $consulta = @ pg_query( $conexion, $sql2 );
      if ( $consulta ) {
        while ( $fila = pg_fetch_array( $consulta ) ) {
            $resultado[] = $fila;
        }
      } else {
        # Esta parte la hice para depurado, comentar esta linea si no se desea ver los resultados
       #echo "<br>No se ejecuto la sentencia <br><pre>sql , $sql2</pre> <br>";
      }
    } else {
      echo "<br>No hay conexi&oacute;n<br>";
    }
    return $resultado;
  }

  function ejecutar( $sql ){
    $conexion = conectar();
    $resultado = FALSE;
    if ( $conexion ) {
      $consulta = @ pg_query( $conexion, htmlentities($sql) );
      if ( $consulta ) {
        $resultado = TRUE;
      } else {
        # Esta parte la hice para depurado, comentar esta linea si no se desea ver los resultados
        echo "<br>No se ejecuto la sentencia <br><pre>$sql</pre> <br>";
      }
    } else {
      echo "<br>No hay conexi&oacute;n<br>";
    }
    return $resultado;
  }
  


?>
