<?php
  $SERVIDOR_DE_BASE_DE_DATOS = "localhost";
  $BASE_DE_DATOS             = "paes";
  $USUARIO_DE_BASE_DE_DATOS  = "manuel";
  $CLAVE_DE_BASE_DE_DATOS    = "manu";
  
  $NOMBRE_SISTEMA 			 = "TEST-PREPAES";

  #correo del administrador
  $CORREO_ADMIN = "manuel.ntonio@gmail.com";
 # include "./funciones/funciones.php";
  #correo_admin ();
  
?>
