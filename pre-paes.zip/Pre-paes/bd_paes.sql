DROP VIEW perfil_usuario;

DROP VIEW vitacora_resultados_en_sesiones;

DROP VIEW mejores_notas_cada_materia;

DROP VIEW top_promedio;

DROP TABLE opcion;

DROP TABLE ask;

DROP TABLE historial_sesiones;

DROP TABLE historial_promedios;

DROP TABLE usuario;

DROP TABLE admon;

DROP TABLE instituto;

DROP TABLE materia;

DROP TABLE rol_admin;

DROP TABLE tema;

DROP TABLE truefalse;

CREATE TABLE truefalse (
  idtruefalse SERIAL   NOT NULL ,
  opcion_es TEXT      ,
PRIMARY KEY(idtruefalse));




CREATE TABLE tema (
  idtema SERIAL   NOT NULL ,
  tematica TEXT      ,
  referencia TEXT   ,
  libro_autor TEXT   ,
PRIMARY KEY(idtema));




CREATE TABLE rol_admin (
  idrol_admin SERIAL   NOT NULL ,
  rol_admin TEXT      ,
PRIMARY KEY(idrol_admin));




CREATE TABLE materia (
  idmateria SERIAL   NOT NULL ,
  materia TEXT    UNIQUE  ,
PRIMARY KEY(idmateria));




CREATE TABLE instituto (
  idinstituto SERIAL   NOT NULL ,
  instituto TEXT   UNIQUE   ,
PRIMARY KEY(idinstituto));




CREATE TABLE admon (
  idadmon SERIAL   NOT NULL ,
  rol_admin_idrol_admin INTEGER   NOT NULL ,
  nombres TEXT    ,
  apellidos TEXT    ,
  nickname TEXT    ,
  correo TEXT    ,
  pass TEXT      ,
PRIMARY KEY(idadmon)  ,
  FOREIGN KEY(rol_admin_idrol_admin)
    REFERENCES rol_admin(idrol_admin)
      ON DELETE CASCADE
      ON UPDATE CASCADE);


CREATE INDEX admon_FKIndex1 ON admon (rol_admin_idrol_admin);


CREATE INDEX IFK_se_identifica ON admon (rol_admin_idrol_admin);


CREATE TABLE usuario (
  idusuario SERIAL   NOT NULL ,
  instituto_idinstituto INTEGER   NOT NULL ,
  nombres TEXT    ,
  apellidos TEXT    ,
  departamento TEXT	,
  correo TEXT    ,
  pass TEXT      ,
  fecha_registro DATE    ,
  hora_registro TIME      ,
PRIMARY KEY(idusuario)  ,
  FOREIGN KEY(instituto_idinstituto)
    REFERENCES instituto(idinstituto)
      ON DELETE CASCADE
      ON UPDATE CASCADE);


CREATE INDEX usuario_FKIndex1 ON usuario (instituto_idinstituto);


CREATE INDEX IFK_pertenece ON usuario (instituto_idinstituto);

CREATE TABLE historial_promedios (
  idhistorial_promedios SERIAL   NOT NULL ,
  usuario_idusuario INTEGER   NOT NULL ,
  fecha DATE    ,
  hora TIME    ,
  promedio NUMERIC      ,
PRIMARY KEY(idhistorial_promedios, usuario_idusuario)  ,
  FOREIGN KEY(usuario_idusuario)
    REFERENCES usuario(idusuario)
      ON DELETE CASCADE
      ON UPDATE CASCADE);


CREATE INDEX historial_promedios_FKIndex1 ON historial_promedios (usuario_idusuario);


CREATE INDEX IFK_obtiene ON historial_promedios (usuario_idusuario);


CREATE TABLE historial_sesiones (
  idhistorial_sesiones SERIAL   NOT NULL ,
  materia_idmateria INTEGER   NOT NULL ,
  usuario_idusuario INTEGER   NOT NULL ,
  fecha DATE    ,
  hora TIME    ,
  respuestas_acertadas NUMERIC    ,
  respuestas_erroneas NUMERIC    ,
  nota_final NUMERIC      ,
PRIMARY KEY(idhistorial_sesiones, materia_idmateria, usuario_idusuario)    ,
  FOREIGN KEY(materia_idmateria)
    REFERENCES materia(idmateria)
      ON DELETE CASCADE
      ON UPDATE CASCADE,
  FOREIGN KEY(usuario_idusuario)
    REFERENCES usuario(idusuario)
      ON DELETE CASCADE
      ON UPDATE CASCADE);


CREATE INDEX historial_sesiones_FKIndex1 ON historial_sesiones (materia_idmateria);
CREATE INDEX historial_sesiones_FKIndex2 ON historial_sesiones (usuario_idusuario);


CREATE INDEX IFK_distingue ON historial_sesiones (materia_idmateria);
CREATE INDEX IFK_realiza ON historial_sesiones (usuario_idusuario);



CREATE TABLE ask (
  idask SERIAL   NOT NULL ,
  tema_idtema INTEGER   NOT NULL ,
  materia_idmateria INTEGER   NOT NULL ,
  pregunta TEXT    ,
  img TEXT      ,
PRIMARY KEY(idask, tema_idtema)    ,
  FOREIGN KEY(materia_idmateria)
    REFERENCES materia(idmateria),
  FOREIGN KEY(tema_idtema)
    REFERENCES tema(idtema)
      ON DELETE CASCADE
      ON UPDATE CASCADE);


CREATE INDEX ask_FKIndex1 ON ask (materia_idmateria);
CREATE INDEX ask_FKIndex2 ON ask (tema_idtema);


CREATE INDEX IFK_pertenece ON ask (materia_idmateria);
CREATE INDEX IFK_proviene ON ask (tema_idtema);


CREATE TABLE opcion (
  idopcion SERIAL   NOT NULL ,
  truefalse_idtruefalse INTEGER   NOT NULL ,
  ask_idask INTEGER   NOT NULL ,
  opcion TEXT    ,
  literal TEXT    ,
  imagen TEXT      ,
PRIMARY KEY(idopcion)    ,

  FOREIGN KEY(truefalse_idtruefalse)
    REFERENCES truefalse(idtruefalse)
      ON DELETE CASCADE
      ON UPDATE CASCADE
    );





-- INSERT ################################

-- admin #################################

INSERT INTO rol_admin (rol_admin)
VALUES ('super_administrador');
INSERT INTO rol_admin (rol_admin)
VALUES ('administrador_sociales');
INSERT INTO rol_admin (rol_admin)
VALUES ('administrador_matematica');
INSERT INTO rol_admin (rol_admin)
VALUES ('administrador_lenguaje');
INSERT INTO rol_admin (rol_admin)
VALUES ('administrador_ciencias');

-- usuario demo_instituto ############################

INSERT INTO instituto (instituto)
VALUES ('');

--  tematicas ##########################
INSERT INTO tema (tematica, referencia, libro_autor)
VALUES ('', '', '');

--  materia ############################
INSERT INTO materia (materia)
VALUES ('sociales');
INSERT INTO materia (materia)
VALUES ('matemáticas');
INSERT INTO materia (materia)
VALUES ('ciencias');
INSERT INTO materia (materia)
VALUES ('lenguaje');

-- true or false ########################
INSERT INTO truefalse (opcion_es)
VALUES ('falso');
INSERT INTO truefalse (opcion_es)
VALUES ('verdadero');
INSERT INTO truefalse (opcion_es)
VALUES ('sin_responder');

--  registrando un user ###################

--INSERT INTO usuario (instituto_idinstituto, nombres, apellidos, correo, pass, fecha_registro, hora_registro)
--VALUES ('1', 'demo_nombre', 'demo_apellido', 'demo_correo', 'abc', '2015-10-07', '17:35:27');


--  ask ####################################

-- sociales ############
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '1', 'vacio', 'ninguna');

-- matemáticas ###########
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '2', 'vacio', 'ninguna');

-- ciencias ###########
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '3', 'vacio', 'ninguna');


-- lenguaje ###########
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');
INSERT INTO ask (tema_idtema, materia_idmateria, pregunta, img)
VALUES ('1', '4', 'vacio', 'ninguna');


--  Tabla Vistas ###################################

CREATE VIEW top_promedio
AS select
	a.usuario_idusuario,
	max(promedio) as promedio,
	a.fecha,
	a.hora,
	b.nombres,
	b.apellidos,
	c.instituto	
from 
	historial_promedios as a,
	usuario as b,
	instituto as c
where
	a.usuario_idusuario = b.idusuario and
	b.instituto_idinstituto = c.idinstituto
GROUP BY 
	a.usuario_idusuario,
	promedio,
	a.fecha,
	a.hora,
	b.nombres,
	b.apellidos,
	c.instituto
ORDER BY promedio desc;

CREATE VIEW mejores_notas_cada_materia
AS SELECT 
      distinct on (materia_idmateria, materia, usuario_idusuario)
      materia_idmateria,
      a.materia,
      usuario_idusuario,
      fecha,
      hora,
      nota_final
    from 
      historial_sesiones,
      materia as a
    WHERE
      usuario_idusuario = usuario_idusuario and
      a.idmateria = materia_idmateria
    ORDER BY
      materia_idmateria, materia, usuario_idusuario, nota_final desc, fecha desc, hora desc;


CREATE VIEW vitacora_resultados_en_sesiones
AS SELECT 
      materia_idmateria,
      a.materia,
      usuario_idusuario,
      fecha,
      hora,
      respuestas_acertadas,
      respuestas_erroneas,
      nota_final
    FROM 
      historial_sesiones,
      materia as a
    WHERE
      usuario_idusuario = usuario_idusuario and
      a.idmateria = materia_idmateria 
    ORDER BY
      fecha desc, hora desc;

CREATE VIEW perfil_usuario
AS SELECT
	idusuario,
	nombres,
	apellidos,
	departamento,
	correo,
	fecha_registro,
	hora_registro,
	idinstituto,
	instituto
	FROM 
	usuario,
	instituto
	WHERE 
	instituto_idinstituto = idinstituto
	ORDER BY
	fecha_registro desc, hora_registro desc;
