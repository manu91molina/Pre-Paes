
<?
 header("Cache-Control: no-cache");
 header("Pragma: no-cache");
 ini_set("session.cookie_lifetime","15400");
 ini_set("session.gc_maxlifetime","15400");
 session_start();
 include "./funciones/funciones.php";
  validar_usuario();
  head ();
  body ();
  cierre_body ();

?>
