<?
echo "<body>";
echo "<div class='demo-layout mdl-layout mdl-js-layout  mdl-layout--fixed-header'>";
# aquí introducimos el menu-panel
include "./estructura/menu.php";
echo "<main class='mdl-layout__content mdl-color--grey-100'>";
# verificar si existe usuario admin
$vector_de_usuarios = consultar("select * from admon;");
$cantidada_de_usuarios = count( $vector_de_usuarios );

$contenido  = @ $_REQUEST['contenido'];

if ($cantidada_de_usuarios) {
		switch ($contenido){
		                    case "sociales":
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/editar_preguntas.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }
		                    break;
		                    case "matematicas":
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/editar_preguntas.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }
		                    break;
		                    case "ciencias":
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/editar_preguntas.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }
		                    break;
		                    case "lenguaje":
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/editar_preguntas.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }
		                    break;
		                    case "usuarios":
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/usuarios.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }
		                    break;
		                    case "top":
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/top_promedios.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }
		                    break;
		                    case "correos":
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/correos_usuarios.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }
		                    break;
		                    case "vista_previa":
		                    	include "./aplicaciones/vista_previa.php";
		                    break;
		                    case "guardar_edit_ask":
		                    	include "./aplicaciones/vista_previa.php";
		                    break;
		                    #registrar administrador
		                    case "ingresar_admin":
		                    	include "./aplicaciones/registrar_admin.php";
		                    break;
		                    default :
		                      if ( isset( $_SESSION['idadmon'] ) ){
		                        include "./aplicaciones/interfaz_admin.php";
		                      }else{
		                        include "./aplicaciones/iniciar_admin.php";
		                      }

		                    break;
		}
}else{

	#si no existe ningun usuario, significa que se debe registrar el primer usuario de tipo administrador
	include "./aplicaciones/registrar_admin.php";
}





?>