<?
?>
            <footer class='mdl-mini-footer'>
              <div class='mdl-mini-footer__left-section'>
                <div class='mdl-logo'>
                  <p>Copyleft test paes 2016</p>
                </div>
              </div>
            </footer>

      </main>
    </div>


    <script src='./recursos/material.min.js'></script>
  </body>
</html>
 