<?

 $materia  		        = @ $_REQUEST['materia'];
 $preguntas_materia   = @ $_REQUEST['contenido'];
 $idask  			        = @ $_REQUEST['idask'];
 $reeditar_ask        = @ $_REQUEST['reeditar_ask'];
 $img        = @ $_REQUEST['img'];


$tipo_imagen 	= @ $_FILES["userfile"]["type"];
$nombreimagen	= @ $_FILES['userfile']['name'];

	if ($preguntas_materia && !$idask) {
		echo "
      <div class='mdl-grid'>
        <div class='mdl-grid demo-content'>
          <div class='demo-charts mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
		        <div class='mdl-card__actions mdl-card mdl-shadow--8dp'>
				    <table class='mdl-data-table mdl-js-data-table'>
				      <thead>
                <tr>
                  <th colspan='4'>
                  <center><h5>";nombre_materia ($preguntas_materia);echo"</h5><center>
                  </th>
                </tr>
				      ";
				  	listar_preguntas ($preguntas_materia);
	  	echo"
				      </thead>
				    </table>
            </div>
		      </div>
		    </div>
	    </div> <!-- /container -->

		";
	}

	if ($preguntas_materia && ($idask || $reeditar_ask)) {
echo "
     <div class='mdl-grid'>
        <div class='mdl-grid demo-content'>
          <div class='demo-charts mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
            <div class='demo-card-square mdl-card mdl-shadow--2dp'>
              <div class='mdl-card__title mdl-card--expand'>
                <h2 class='mdl-card__title-text'>";nombre_materia ($preguntas_materia);echo"</h2>
              </div>
              <form ' method='post' action='./' enctype='multipart/form-data'>
              <div class='mdl-card__supporting-text'>

                <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
			    	      <textarea type='text' name='ask' class='mdl-textfield__input' rows= '7' id='sample1' >";ask ($idask);echo"</textarea>
			    	      <label class='mdl-textfield__label' for='sample1'>Editar pregunta <i class='material-icons'>help</i></label>
			  	      </div>
                </br>
              ";
        if ($img && ($img <> "ninguna")) {
          echo "<details>";
            echo "<summary>Anular imagen actual<i class='material-icons'>broken_image</i></summary>";
            echo "<img class='img-reemplazar' src='.$img' alt='' />";
            echo "<label class='mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect' for='checkbox-2'>
                    <input type='checkbox' name='anular_img' value='null' id='checkbox-2' class='mdl-checkbox__input' />
                    <span class='mdl-checkbox__label'>Anular</span>
                  </label>";
          echo "</details>";
          echo "<details>
                  <summary>Reemplazar imagen<i class='material-icons'>photo_size_select_larges</i></summary>";
        }else{
          echo "<details>
                  <summary>Insertar imagen <i class='material-icons'>photo</i></summary>";
        }
              echo"
                      <div id='botonera'>
                          <input class='mdl-button mdl-js-button mdl-button--accent' name='imagen' id='archivo' type='file' accept='image/*' />
                          <input class='mdl-button mdl-js-button mdl-button--primar' id='cancelar' type='button' value='Cancelar'></input>
                      </div>
                      <div class='contenedor'>
                          <div class='titulo'>
                              <!-- <span>Vista Previa:</span> -->
                              <!--<span id='infoNombre'>[Seleccione una imagen]</span><br/>-->
                              <small id='infoTamaño'></small>
                          </div>
                          <div  id='marcoVistaPrevia'>
                              <img class='img-prev' id='vistaPrevia' src='' alt='' />
                          </div>
                      </div>
                    <p>Tamaño máximo 25MB.</p>
                </details></br>

                <details>
                  <summary>Referencia Bibliográfica<i class='material-icons'>local_library</i></summary>
                    <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                      <input name='tema' class='mdl-textfield__input' value='";edit_tema ($idask); echo"' type='text' id='sample3' />
                      <label class='mdl-textfield__label' for='sample3'>Tema al que pertenece...<label>
                    </div></br>
                    <div class='mdl-textfield mdl-js-textfield mdl-textfield--expandable'>
                      <label class='mdl-button mdl-js-button mdl-button--icon' for='sample6'>
                        <i class='material-icons'>book</i>
                      </label>
                      <div class='mdl-textfield__expandable-holder'>
                        <input name='libro' value='";edit_libro ($idask); echo"' class='mdl-textfield__input' placeholder='nombre de libro y autor...' type='text' id='sample6' ></textarea>
                        <label class='mdl-textfield__label' for='sample-expandable'>Expandable Input</label>
                      </div>
                    </div></br>
                    <div class='mdl-textfield mdl-js-textfield mdl-textfield--expandable'>
                      <label class='mdl-button mdl-js-button mdl-button--icon' for='sample7'>
                        <i class='material-icons'>link</i>
                      </label>
                      <div class='mdl-textfield__expandable-holder'>
                        <input name='enlace1'  value='";edit_enlace1 ($idask); echo"' class='mdl-textfield__input' placeholder='http://www.ejemplo.com/...' type='text' id='sample7' />
                        <label class='mdl-textfield__label' for='sample-expandable'>Expandable Input</label>
                      </div>
                    </div></br>
                    <div class='mdl-textfield mdl-js-textfield mdl-textfield--expandable'>
                      <label class='mdl-button mdl-js-button mdl-button--icon' for='sample8'>
                        <i class='material-icons'>link</i>
                      </label>
                      <div class='mdl-textfield__expandable-holder'>
                        <input name='enlace2' value='";edit_enlace2 ($idask); echo"' class='mdl-textfield__input' placeholder='http://www.ejemplo.com/...' type='text' id='sample8' />
                        <label class='mdl-textfield__label' for='sample-expandable'>Expandable Input</label>
                      </div>
                    </div>
                </details>
              </div>


              <!-- introducir las opciones -->
              <div class='mdl-tabs mdl-js-tabs mdl-js-ripple-effect'>
                <div class='mdl-tabs__tab-bar'>
                    <a href='#starks-panel' class='mdl-tabs__tab'>INGRESAR OPCIONES</a>
                </div>

                <div class='mdl-tabs__panel is-active' id='starks-panel'>
                  <ol>
                    <li class='list-unstyled'>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input name='opc_a' value='";a_opcion_edit ($idask); echo"' class='mdl-cell--12-col mdl-textfield__input' type='text' id='sample3' />
                        <label class='mdl-cell--12-col mdl-textfield__label' for='sample3'>opción A...</label>
                      </div>
                    </li>
                    <li class='list-unstyled'>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input name='opc_b' value='";b_opcion_edit ($idask); echo"' class='mdl-cell--12-col mdl-textfield__input' type='text' id='sample3' />
                        <label class='mdl-cell--12-col mdl-textfield__label' for='sample3'>opción B...</label>
                      </div>
                    </li>
                    <li class='list-unstyled'>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input name='opc_c' value='";c_opcion_edit ($idask); echo"' class='mdl-cell--12-col mdl-textfield__input' type='text' id='sample3' />
                        <label class='mdl-cell--12-col mdl-textfield__label' for='sample3'>opción C...</label>
                      </div>
                    </li>
                    <li class='list-unstyled'>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input name='opc_d' value='";d_opcion_edit ($idask); echo"' class='mdl-cell--12-col mdl-textfield__input' type='text' id='sample3' />
                        <label class='mdl-cell--12-col mdl-textfield__label' for='sample3'>opción D...</label>
                      </div>
                    </li>
                  </ol>
                  
                </div>
              </div>
                 

              <!--opciones-->
              <div class='mdl-card__actions mdl-card--border'>
                <center>
                <div class='mdl-tabs__tab-bar'>
                    <a href='#starks-panel' class='mdl-tabs__tab'>DEFINIR OPCIÓN CORRECTA</a>
                </div>
                <table class='mdl-card__actions mdl-data-table'>
                  <thead>
                    <tr>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-1'>
                          <input type='radio' id='option-1' class='mdl-radio__button' name='options' value='a'"; $true="a"; opction_true_edit ($idask, $true); echo" />
                            A.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-2'>
                          <input type='radio' id='option-2' class='mdl-radio__button' name='options' value='b'"; $true="b"; opction_true_edit ($idask, $true); echo"/>
                            B.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-3'>
                          <input type='radio' id='option-3' class='mdl-radio__button' name='options' value='c'"; $true="c"; opction_true_edit ($idask, $true); echo"/>
                            C.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-4'>
                          <input type='radio' id='option-4' class='mdl-radio__button' name='options' value='d'"; $true="d"; opction_true_edit ($idask, $true); echo"/>
                            D.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                    </tr>
                  </thead>
                </table></center>
                <input type='hidden' name='edit_idask' value='$idask'>
                <input type='hidden' name='materia' value='$preguntas_materia'>
                <!-- Accent-colored raised button with ripple -->
                <button type='submit' name='contenido' value='guardar_edit_ask' class='mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored'>
                  <i class='material-icons'>check</i>
                </button>  &nbsp; &nbsp; &nbsp;
                <!-- Accent-colored raised button with ripple -->
                <button type='submit' name='contenido' value='$preguntas_materia' class='mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored'>
                  <i class='material-icons'>close</i>
                </button>
              </form>
              </div>
            </div>
          </div>
        </div>
      </div>

";
	}





?>
