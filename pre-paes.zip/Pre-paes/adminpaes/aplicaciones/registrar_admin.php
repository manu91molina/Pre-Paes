<?
#function random(){
#
#            $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890";
#            $cad = "";
#            for($i=0;$i<10;$i++) {
#                $cad .= substr($str,rand(0,120),1);
#            }
#
#    return $cad;
#}

$correo  			= @ $_REQUEST['correo'];
$nombres  		= @ $_REQUEST['nombres'];
$apellidos  	= @ $_REQUEST['apellidos'];
$contraseña1	= @ $_REQUEST['contraseña1'];
$contraseña2  	= @ $_REQUEST['contraseña2'];


if ($contraseña1 <> $contraseña2) {

echo "
    <form class='form-signin' method='post' action='./index.php?contenido=ingresar_admin' enctype='multipart/form-data'>

    <div class='mdl-grid'>
       <div class='demo-charts mdl-color--blue-grey-800 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
                
                <div class='mdl-layout-spacer'></div>
                <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--5-col mdl-shadow--2dp'>
                    <div class='mdl-card__title mdl-card--expand'>

                      <h2 class='mdl-card__title-text'>CREAR CUENTA DE ADMINISTRADOR</h2>
                    </div>
                    <div class='mdl-card__supporting-text mdl-cell--12-col'>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input class='mdl-textfield__input' value='$correo' name='correo'  type='email' required>
                          <label class='mdl-textfield__label' for='correo'>CORREO</label>
                        </div>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input id='nombres' class='mdl-textfield__input' name='nombres'  type='text' pattern='[A-Z,a-z, ]*' required>
                          <label class='mdl-textfield__label' value='$nombres' for='nombres'>NOMBRES</label>
                          <div class='mdl-tooltip' for='nombres'>
                            solo letras y espacios
                          </div>
                        </div>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input id ='apellidos' class='mdl-textfield__input' name='apellidos'  type='text' pattern='[A-Z,a-z, ]*' required>
                          <label class='mdl-textfield__label' value='$apellidos' for='apellidos'>APELLIDOS</label>
                          <div class='mdl-tooltip' for='apellidos'>
                            solo letras y espacios
                          </div>
                        </div>
                        <div class='mdl-textfield  mdl-textfield--align-left'>
                          <span id='error' class='material-icons mdl-color-text--red-700 mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='!'>person_pin</span>
                          <div class='mdl-color--red-700 mdl-tooltip' for='error'>
                                LAS CONTRASEÑAS NO COINCIDEN
                          </div>
                        </div>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input id ='pssword1' pattern='.{8,}'  class='mdl-textfield__input' name='contraseña1'  type='password' required>
                          <label class='mdl-textfield__label' for='pssword1'>CREAR CONTRASEÑA</label>
                          <div class='mdl-tooltip' for='pssword1'>
                            mínimo 8 caracteres
                          </div>
                        </div>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input id ='pssword2' pattern='.{8,}'  class='mdl-textfield__input' name='contraseña2'  type='password' required>
                          <label class='mdl-textfield__label' for='pssword2'>CONFIRMAR CONTRASEÑA</label>
                          <div class='mdl-tooltip' for='pssword2'>
                            deben coincidir ambas contraseñas
                          </div>
                        </div>
                      <center>    
                        <input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='CREAR CUENTA'>
                      </center>
                      </form>
                    </div>
                </div>     
        <div class='mdl-layout-spacer'></div>
      </div>
    </div>
   </form>

";
      #  <label for='exampleInputFile'>Adjunte Foto</label>
      #    <div id='botonera'>
      #        <input name='userfile'  id='archivo' type='file' accept='image/*' />
      #        <input id='cancelar' type='button' value='Cancelar'></input>
      #    </div>
      # descarte el formulario para adjuntar imagen al usuario admin
      #    <div class='contenedor'>
       #       <div class='titulo'>
      #            <!-- <span>Vista Previa:</span> -->
      #            <!--<span id='infoNombre'>[Seleccione una imagen]</span><br/>-->
      #            <span id='infoTamaño'></span>
      #        </div>
      #        <div  id='marcoVistaPrevia'>
      #            <img  width='20%' id='vistaPrevia' src=' alt=' />
      #        </div>
      #    </div>
      #  <p class='help-block'>Tamaño máximo 20MB.</p>
      #  <button class='btn btn-lg btn-primary btn-block' type='submit'>Registrar</button>
      #  <input type='hidden' name='municipio' value='$municipio'>
      #</form>

}else{
	if (!$contraseña1 && !$contraseña2) {
		echo "
		<form class='form-signin' method='post' action='./index.php?contenido=ingresar_admin' enctype='multipart/form-data'>

    <div class='mdl-grid'>
       <div class='demo-charts mdl-color--blue-grey-800 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
                
                <div class='mdl-layout-spacer'></div>
                <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--5-col mdl-shadow--2dp'>
                    <div class='mdl-card__title mdl-card--expand'>

                      <h2 class='mdl-card__title-text'>CREAR CUENTA DE ADMINISTRADOR</h2>
                    </div>
                    <div class='mdl-card__supporting-text mdl-cell--12-col'>

                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input class='mdl-textfield__input' name='correo'  type='email' required>
                          <label class='mdl-textfield__label' for='correo'>CORREO</label>
                        </div>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input id='nombres' class='mdl-textfield__input' name='nombres'  type='text' pattern='[A-Z,a-z, ]*' required>
                          <label class='mdl-textfield__label' for='nombres'>NOMBRES</label>
                          <div class='mdl-tooltip' for='nombres'>
                            solo letras y espacios
                          </div>
                        </div>
                        <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                          <input id ='apellidos' class='mdl-textfield__input' name='apellidos'  type='text' pattern='[A-Z,a-z, ]*' required>
                          <label class='mdl-textfield__label' for='apellidos'>APELLIDOS</label>
                          <div class='mdl-tooltip' for='apellidos'>
                            solo letras y espacios
                          </div>
                        </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword1' pattern='.{8,}'  class='mdl-textfield__input' name='contraseña1'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword1'>CREAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword1'>
                          mínimo 8 caracteres
                        </div>
                      </div>
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input id ='pssword2' pattern='.{8,}'  class='mdl-textfield__input' name='contraseña2'  type='password' required>
                        <label class='mdl-textfield__label' for='pssword2'>CONFIRMAR CONTRASEÑA</label>
                        <div class='mdl-tooltip' for='pssword2'>
                          deben coincidir ambas contraseñas
                        </div>
                      </div>
                      <center>    
                        <input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='CREAR CUENTA'>
                      </center>
                      </form>
                    </div>
                </div>     
        <div class='mdl-layout-spacer'></div>
      </div>
    </div>
   </form>
";
	}else{
		    $vector_usuario = consultar("select * from admon where correo = '$correo';");
		    $cantidad_usuarios = count( $vector_usuario );
        if ($cantidad_usuarios == 0) {
              $contraseñamd5 = md5($contraseña1);
              $sql="
              INSERT INTO admon (rol_admin_idrol_admin, nombres, apellidos, correo, pass)
              VALUES ('1', '$nombres', '$apellidos', '$correo', '{$contraseñamd5}');";
              #ejecutar sql
              $resultado = ejecutar( $sql );

              echo  "
                  <div class='demo-charts mdl-cell mdl-color--white mdl-shadow--2dp mdl-cell--12-col mdl-grid'>
                        <div class='mdl-cell mdl-layout-spacer'></div>
                        <div class='demo-card-square-cyan mdl-cell mdl-card mdl-cell--4-col mdl-shadow--4dp'>
                            <div class='mdl-card__title'>
                              <h2 class='mdl-card__title-text'>TU CUENTA SE HA CREADO</h2>
                            </div>
                            <div class='mdl-color--cyan-900  mdl-card--expand mdl-color-text--white mdl-card__supporting-text'>
              ";
                          echo "Estas registrado $nombres $apellidos como administrador. </br>";
                          echo "Recuerda que con tu  correo <b>$correo</b> ingresarás al sistema. </br>";
                          echo      "<form name='form1' method='post' action='./'><input class='mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect' type='submit' value='ENTRAR'><input type='hidden' name='contraseña' value='$contraseña1'><input type='hidden' name='correo' value='$correo'><input type='hidden' name='contenido' value='iniciar'></form>";
                          echo  "
                            </div>
                        </div>
                        <div class='mdl-cell mdl-layout-spacer'></div>  
                  </div>
              ";
              include "./configuraciones/principal.php";
              $mensaje="Notificación: Eres administrador del sistema de test para paes."."\n"."plataformas.uls.edu.sv/prepaes";
              mail($correo, "sistema test paes", "$mensaje");
              
        }else{
          echo "
          <div class='alert alert-danger' role='alert'>
            Este usuario ya esta registrado con el correo $correo, $nombres $apellidos.
          </div>";
        }

	}
}







?>
