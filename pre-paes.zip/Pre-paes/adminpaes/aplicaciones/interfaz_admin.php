<?
echo"
        <div class='android-more-section'>
          <div class='android-section-title mdl-typography--display-1-color-contrast'><i class='material-icons'>build</i> Editar TEST</div>
          <div class='android-card-container mdl-grid'>    
            <div class='mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone mdl-card mdl-shadow--3dp'>
              <div class='mdl-card__title'>
                 <h4 class='mdl-card__title-text'>Estudios Sociales</h4>
              </div>
              <div class='mdl-card__supporting-text'>
                <form method='post' action='./'> 
                  <button type='submit' name='contenido' value='sociales' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>
				            Editar Preguntas <i class='material-icons'>help</i>
			            </button> 
                </form>      
              </div>
            </div>

            <div class='mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone mdl-card mdl-shadow--3dp'>
              <div class='mdl-card__title'>
                 <h4 class='mdl-card__title-text'>Matemáticas</h4>
              </div>
              <div class='mdl-card__supporting-text'>
                <form method='post' action='./'> 
                  <button type='submit' name='contenido' value='matematicas' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>
                    Editar Preguntas <i class='material-icons'>help</i>
                  </button> 
                </form>      
              </div>
            </div>

            <div class='mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone mdl-card mdl-shadow--3dp'>
              <div class='mdl-card__title'>
                 <h4 class='mdl-card__title-text'>Ciencias Salud y Medio Ambiente</h4>
              </div>
              <div class='mdl-card__supporting-text'>
                <form method='post' action='./'> 
                  <button type='submit' name='contenido' value='ciencias' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>
                    Editar Preguntas <i class='material-icons'>help</i>
                  </button> 
                </form>  
              </div>
            </div>

            <div class='mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet mdl-cell--4-col-phone mdl-card mdl-shadow--3dp'>
              <div class='mdl-card__title'>
                 <h4 class='mdl-card__title-text'>Lenguaje y Literatura</h4>
              </div>
              <div class='mdl-card__supporting-text'>
                <form method='post' action='./'> 
                  <button type='submit' name='contenido' value='lenguaje' class='mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent'>
                    Editar Preguntas <i class='material-icons'>help</i>
                  </button> 
                </form>  
              </div>
            </div>
          </div>
        </div>


";
?>