<?
echo "
	<div class='demo-charts mdl-color--blue-grey-700 mdl-color-text--white mdl-shadow--4dp mdl-cell--6-col mdl-grid'>
		  <div class='mdl-layout-spacer'></div>
		  <div class='android-section-title mdl-typography--display-1-color-contrast'>
	 		INGRESAR AL SISTEMA
		  </div>
		  <div class='mdl-layout-spacer'></div>
	</div>
	<div class='mdl-grid'>

	    <div class='demo-charts mdl-color--blue-grey-700 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
	            <div class='mdl-layout-spacer'></div>
	            <div class='demo-card-square-cyan mdl-shadow--2dp mdl-card--expand mdl-cell mdl-card mdl-cell--2-col mdl-shadow--1dp'>
                  <div class='mdl-card__title mdl-card--expand'>

                  </div>
		          <div class='mdl-textfield mdl-cell--12-col mdl-js-textfield mdl-textfield--floating-label'>
		            <form method='post' action='./'>     
		            <input class='mdl-textfield__input' name='correo'  type='email'>
		            <label class='mdl-textfield__label' for='correo'>CORREO</label>
		          </div>

		          <div class='mdl-textfield mdl-cell--12-col mdl-js-textfield mdl-textfield--floating-label'>
		            <input class='mdl-textfield__input' name='contraseña'  type='password'>
		            <label class='mdl-textfield__label' for='contraseña'>CONTRASEÑA</label>
		          </div>

		          <button name='contenido' value='iniciar' class='mdl-color-text--cyan mdl-button mdl-js-button mdl-js-ripple-effect'>INICIAR</button>
		          <br><br>
		          </form>
	            </div>
	            <div class='mdl-layout-spacer'></div>	
		</div>
	</div>

";

?>