<?
$materia      = @ $_REQUEST['materia'];
$idask        = @ $_REQUEST['edit_idask'];
$guardar      = @ $_REQUEST['contenido'];
$ask          = @ $_REQUEST['ask'];
$tema         =@ $_REQUEST['tema'];
$libro        =@ $_REQUEST['libro'];
$enlace1      =@ $_REQUEST['enlace1'];
$enlace2      =@ $_REQUEST['enlace2'];
$opc_a        =@ $_REQUEST['opc_a'];
$opc_b        =@ $_REQUEST['opc_b'];
$opc_c        =@ $_REQUEST['opc_c'];
$opc_d        =@ $_REQUEST['opc_d'];
 #$opc_e        =@ $_REQUEST['opc_e'];

$options_true       =@ $_REQUEST['options']; ## <- identifica la opcion true

$vista_previa = @ $_REQUEST['idask'];
$tipo_imagen  = @ $_FILES['imagen']['type'];
$nombreimagen = @ $_FILES['imagen']['name'];
$imagen       =@ $_FILES['imagen']['tmp_name'];
$anular_img          =@ $_REQUEST['anular_img'];
$img          =@ $_REQUEST['img'];

if ($vista_previa && !$guardar) {
  echo "nada aun";
}else{
  if ($ask && !$tipo_imagen) {
	  if($anular_img){
      echo "editando_ask_anular_imagen <br>";
		editando_ask_anular_imagen ($idask, $ask, $anular_img, $tema, $libro, $enlace1, $enlace2);
	  }else{
      echo "editando_pregunta <br>";
		  editando_pregunta ($idask, $ask, $tema, $libro, $enlace1, $enlace2);
    }
  }elseif ($ask && $tipo_imagen) {
    echo "editando_ask_img <br>";
    editando_ask_img ($idask, $ask, $imagen, $tipo_imagen, $nombreimagen, $anular_img, $tema, $libro, $enlace1, $enlace2);
  
  }
  echo "

     <div class='mdl-grid'>
        <div class='mdl-grid demo-content'>
          <div class='demo-charts mdl-color--white mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
            <div class='demo-card-square mdl-card mdl-shadow--2dp'>
              <div class='mdl-card__title mdl-card--expand'>
                <h2 class='mdl-card__title-text'>";materia ($materia);echo"</h2>
              </div>
              <form class='' method='post' action='./' enctype='multipart/form-data'>
              
              <div class='mdl-tabs mdl-card__supporting-text'>

              ";ask_con_img ($idask);
              echo"
              </div>

              <div class='mdl-tabs mdl-js-tabs mdl-js-ripple-effect'>
                <div class='mdl-tabs__tab-bar'>
                    <a href='#starks-panel' class='mdl-tabs__tab is-active'>OPCIONES</a>
                </div>

                <div class='mdl-tabs__panel is-active' id='starks-panel'>";
                  if ($opc_a || $opc_b || $opc_c || $opc_d ) {
                    editando_opciones ($idask, $opc_a, $opc_b, $opc_c, $opc_d, $options_true);
                  }
              echo"<ol>
                  ";listar_opciones($idask);
              echo"
                  </ol>
                  
                </div>
              </div>
            
              <!--opcion verdadera-->
              <div class='mdl-card__actions mdl-card--border'>
                <center><table class='mdl-card__actions mdl-data-table'>
                  <thead>
                    <tr>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-1'>
                          <input type='radio' id='option-1' class='mdl-radio__button'"; $true="a"; opction_true ($idask, $true); echo"/>
                            A.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-2'>
                          <input type='radio' id='option-2' class='mdl-radio__button'"; $true="b"; opction_true ($idask, $true); echo" />
                            B.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-3'>
                          <input type='radio' id='option-3' class='mdl-radio__button'"; $true="c"; opction_true ($idask, $true); echo" />
                            C.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                      <th>
                        <label class='mdl-radio mdl-js-radio mdl-js-ripple-effect' for='option-4'>
                          <input type='radio' id='option-4' class='mdl-radio__button'"; $true="d"; opction_true ($idask, $true); echo" />
                            D.<span class='mdl-radio__label'></span>
                        </label>
                      </th>
                    </tr>
                  </thead>
                </table></center>
                <input type='hidden' name='contenido' value='$materia'>
                <!-- Accent-colored raised button with ripple -->
                <button type='submit' name='contenido' value='$materia' class='mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored'>
                  <i class='material-icons'>check</i>
                </button>  &nbsp; &nbsp; &nbsp;
                <!-- Accent-colored raised button with ripple -->
                <button type='submit' name='idask' value='$idask' class='mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored'>
                  <i class='material-icons'>edit</i>
                </button>
              </form>
              </div>
            </div>
          </div>
        </div>
      </div>

  ";
}


?>
