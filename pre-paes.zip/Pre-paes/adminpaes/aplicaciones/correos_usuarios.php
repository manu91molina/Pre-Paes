<?
$instituto	= @$_REQUEST['instituto'];
$mes 		= @$_REQUEST['mes'];

echo "
	<div class='demo-charts mdl-color--blue-grey-700 mdl-color-text--white mdl-shadow--4dp mdl-cell--6-col mdl-grid'>
		<div class='mdl-layout-spacer'></div>
		<div class='android-section-title mdl-typography--display-1-color-contrast'>
	 		<i class='mdl-color-text--blue-grey-A700 material-icons' role='presentation'>contact_mail</i> CORREO DE USUARIOS
		</div>
		<div class='mdl-layout-spacer'></div>
		<details>
		 	<summary class='mdl-color-text--white'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>date_range</i> FILTRAR POR MES</summary>
			  <form method='post' action='./'>
			  	"; 
			  	if ($instituto) {
			  		echo "<input type='hidden' name='instituto' value='$instituto'>";
			  	}
			  	echo"
				  <div id='mes' class='android-section-title mdl-typography--display-1-color-contrast'>
			 		<input class='mdl-textfield__input'  type='month' name='mes' value='$mes' >
			 		<center>
			 			<button name='contenido' value='correos' class='mdl-shadow--4dp mdl-color-text--white mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--white material-icons' role='presentation'>check</i> APLICAR</button>
			 		</center>
				  </div>
			  </form>
		</details>
		<div class='mdl-layout-spacer'></div>
		<details>
		 	<summary class='mdl-color-text--white'><i class='mdl-color-text--green-A700 material-icons' role='presentation'>store</i> FILTRAR POR INSTITUTO</summary>
			  <form method='post' action='./'>
			  	"; 
			  	if ($mes) {
			  		echo "<input type='hidden' name='mes' value='$mes'>";
			  	}
			  	echo"
                      <div class='mdl-textfield mdl-js-textfield mdl-textfield--floating-label'>
                        <input list='buscar' id='instituto' class='mdl-textfield__input' name='instituto' value='$instituto'>
                        <label class='mdl-textfield__label' for='instituto'>INSTITUTO EDUCATIVO</label>
                        ";
                        lista_institutos ();
                        echo"
                        <div class='mdl-tooltip' for='instituto'>
                          solo letras y espacios
                        </div>
                      </div>
                        <center>
			 				<button name='contenido' value='correos' class='mdl-shadow--4dp mdl-color-text--white mdl-button mdl-js-button mdl-js-ripple-effect'><i class='mdl-color-text--white material-icons' role='presentation'>check</i> APLICAR</button>
			 			</center>
			  </form>
		</details>

		  <div class='mdl-layout-spacer'></div>

	</div>
	<div class='mdl-grid'>
	    <div class='demo-charts mdl-color--blue-grey-700 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
	            <div class='demo-card-square-cyan mdl-card--expand mdl-cell mdl-card mdl-cell--12-col mdl-shadow--1dp'>
	              <center>
				  <table class='mdl-color--white mdl-data-table  mdl-shadow--2dp mdl-js-data-table'>
				    <thead>
				      <tr>
				        <th><center><i id='correo' class='mdl-color-text--green-A700 material-icons'>mail</i></center></th>
							<div class='mdl-color--green-700 mdl-tooltip' for='correo'>
                 				 CORREOS
            				</div>
				      </tr>
				    </thead>
				    <tbody>
				  </center>
					";

						listar_correos ($mes, $instituto);

				echo "
				    </tbody>
				  </table>
	            </div>
	         	<div class='mdl-layout-spacer'></div>

		</div>
	</div>
";

?>