 <?
 if ($_SESSION["correo"]) {echo "<link rel='stylesheet' href='./recursos/material.indigo-pink.min.css'>";}

echo "
	<div class='demo-charts mdl-color--blue-grey-700 mdl-color-text--white mdl-shadow--4dp mdl-cell--6-col mdl-grid'>
		  <div class='mdl-layout-spacer'></div>
		  <div class='android-section-title mdl-typography--display-1-color-contrast'>
	 		<i class='mdl-color-text--blue-grey-A700 material-icons' role='presentation'>supervisor_account</i> TOP PROMEDIOS
		  </div>
		  <div class='mdl-layout-spacer'></div>
	</div>
	<div class='mdl-grid'>
	    <div class='demo-charts mdl-color--blue-grey-700 mdl-shadow--2dp mdl-cell mdl-cell--12-col mdl-grid'>
	            <div class='demo-card-square-cyan mdl-card--expand mdl-cell mdl-card mdl-cell--8-col mdl-shadow--1dp'>

					<ul class='demo-list-three mdl-list'>";
						top_promedio ();
						echo "
					</ul>
	            </div>	
		</div>
	</div>
";

?>