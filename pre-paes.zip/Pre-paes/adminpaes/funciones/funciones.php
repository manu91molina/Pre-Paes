<?
function head () {
	include "./estructura/head.php";
}

function menu () {
	include "./estructura/menu.php";
}

function body () {
  include "./estructura/body.php";
}

function cierre_body () {
	include "./estructura/cierre_body.php";
}


function ultimos_usuarios_registrados ($mes, $instituto){
    if ($mes && !$instituto) {
      #echo "mes";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario WHERE  TO_CHAR(fecha_registro,'YYYY-MM')='$mes';");
    }elseif (!$mes && $instituto) {
       #echo "instituto";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario WHERE  instituto='{$instituto}';");
    }elseif ($mes && $instituto) {
       #echo "ambas";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario WHERE  TO_CHAR(fecha_registro,'YYYY-MM')='$mes' and instituto='{$instituto}' ;");
    }else{
      #echo "ninguna";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario;");
    }
    
    
    #cantidad de sesiones a mostrar
    $cantidad_usuario_bd = count($vector_usuarios);
    if ($cantidad_usuario_bd <= 100) {
      $cantidad_usuario = $cantidad_usuario_bd;

    }else{
      #asignar
      $cantidad_usuario = 100;
      $mensaje = "*ya son más de 100 usuarios!! <br> de momento se ha limitado a mostrar <br> los 100 últimos usuarios registrados. <br> Usa los filtros para evitar problemas <br> de consulta en el sistema ";
    }
echo "
<tr>
<td><center>total = $cantidad_usuario</center></td>
<td>$mensaje</td><td></td><td></td><td></td>
</tr>
";
    
    if ( $cantidad_usuario > 0) {
      for ( $contador = 0 ; $contador < $cantidad_usuario; $contador ++ ) {
        $nombres              = $vector_usuarios[$contador]['nombres'];
        $apellidos            = $vector_usuarios[$contador]['apellidos'];
        $departamento         = $vector_usuarios[$contador]['departamento'];
        $fecha_registro       = $vector_usuarios[$contador]['fecha_registro'];
        $hora_registro         = $vector_usuarios[$contador]['hora_registro'];
        $instituto            = $vector_usuarios[$contador]['instituto'];

        $fecha_registro = date("d F 'y", strtotime("$fecha_registro"))."";
        $hora_registo  = date('h:i a', strtotime("$hora_registo"))."";

        
        echo "
            <tr>
              <td><h6><center>$nombres $apellidos</center></h6></td>
              <td><h6><center>$fecha_registro</center></h6></td>
              <td><h6>$hora_registro</h6></td>
              <td><h6>$instituto</h6></td>
              <td><h6><center>$departamento</center></h6></td>
            </tr>
        ";

        }
    }
}


function listar_correos ($mes, $instituto){
    if ($mes && !$instituto) {
      #echo "mes";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario WHERE  TO_CHAR(fecha_registro,'YYYY-MM')='$mes';");
    }elseif (!$mes && $instituto) {
       #echo "instituto";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario WHERE  instituto='{$instituto}';");
    }elseif ($mes && $instituto) {
       #echo "ambas";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario WHERE  TO_CHAR(fecha_registro,'YYYY-MM')='$mes' and instituto='{$instituto}' ;");
    }else{
      #echo "ninguna";
      $vector_usuarios = consultar("SELECT * FROM perfil_usuario;");
    }
    
    
    #cantidad de sesiones a mostrar
    $cantidad_usuario_bd = count($vector_usuarios);
    if ($cantidad_usuario_bd <= 100) {
      $cantidad_usuario = $cantidad_usuario_bd;

    }else{
      #asignar
      $cantidad_usuario = $cantidad_usuario_bd;
      #$mensaje = "*ya son más de 100 usuarios!! <br> de momento se ha limitado a mostrar <br> los 100 últimos usuarios registrados. <br> Usa los filtros para evitar problemas <br> de consulta en el sistema ";
    }
        echo "
          <tr>
            <td><center>total correos = $cantidad_usuario</center></td>
          </tr>
        ";
    
    if ( $cantidad_usuario > 0) {
      echo "<tr>
              <td>
                <div class='mdl-textfield mdl-js-textfield'>
                  <textarea class='mdl-textfield__input' type='text' rows= '15' id='sample5' >";
      for ( $contador = 0 ; $contador < $cantidad_usuario; $contador ++ ) {
        $correo              = $vector_usuarios[$contador]['correo'];
        
        echo "$correo ";

      }
              echo "</textarea>
                    <label class='mdl-textfield__label' for='sample5'>Text lines...</label>
                </div>
              </td>  
            </tr>";
    }
}


function lista_institutos (){

    $institutos = "select * from instituto;";
    $consultar = consultar ( $institutos);
    $verficar_existencia = count($consultar);

    echo "<datalist id='buscar'>";
    if ( $verficar_existencia > 0) {
      for ( $contador = 0 ; $contador < $verficar_existencia ; $contador ++ ) {
          $idinstituto   = $consultar[$contador]['idinstituto'];
          $instituto     = $consultar[$contador]['instituto'];
          echo "<option value='$instituto'>";

        }
    }
    echo "</datalist>";

}

#### filtrar los mejores promedios entre usuarios ####################

function top_promedio (){

  $vector_promedios = consultar("select * from top_promedio ;");
  $cantidad_top = count($vector_promedios);
  ## cantidad de usuarios a mostrar en el top#
  if ($cantidad_top < 20) {
    $top = $cantidad_top;
  }else{
    #si existen mas de 10 promedios registrados mostrar los mejores 20
    $top = 20;
  }

    for ( $contador = 0 ; $contador < $top; $contador ++ ) {
      $idusuario = $vector_promedios[$contador]['usuario_idusuario'];
      $nombres   = $vector_promedios[$contador]['nombres'];
      $apellidos = $vector_promedios[$contador]['apellidos'];
      $instituto = $vector_promedios[$contador]['instituto'];
      $fecha     = $vector_promedios[$contador]['fecha'];
      $hora      = $vector_promedios[$contador]['hora'];
      $promedio  = $vector_promedios[$contador]['promedio'];

      $fecha = date("d F 'y", strtotime("$fecha"))."";
      $hora  = date('h:i a', strtotime("$hora"))."";

      echo "
                  <li class='mdl-list__item mdl-list__item--three-line'>
                    <span class='mdl-list__item-primary-content'>
                      <i class='material-icons mdl-list__item-avatar'>person</i>
                      <span>$nombres $apellidos</span>
                      <span class='mdl-list__item-text-body'>
      ";
                      if (!$instituto) {
                        # 
                      }else{
                        echo "
                        <em><small>$instituto</small></em></br>
                        ";
                      }
      echo "
                         Notas: "; mejor_nota ($idusuario); echo"  Útima Actividad: <em><i class='mdl-color-text--green-A700 material-icons'>date_range</i> $fecha <i class='mdl-color-text--green-A700 material-icons'>watch_later</i>$hora</em>
                      </span>
                    </span>
                    <span class='mdl-list__item-secondary-content'>
                      <sapn class='mdl-list__item-secondary-action' href='#'><h4>$promedio</h4></sapn>
                    </span>
                  </li>
      ";


    }
}



function listar_preguntas ($preguntas_materia){

  switch ($preguntas_materia) {
    case 'sociales':
      $materia = 1;
      break;
    case 'matematicas':
      $materia = 2;
      break;
    case 'ciencias':
      $materia = 3;
      break;
    case 'lenguaje':
      $materia = 4;
      break;   
    default:
      # code...
      break;
  }
    $vector_ask = consultar("select * from ask where materia_idmateria = $materia order by idask;");
    $cantidad_ask = count( $vector_ask );
    if ( $cantidad_ask > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_ask; $contador ++ ) {
        $idask      = $vector_ask[$contador]['idask'];
        $idtema     = $vector_ask[$contador]['tema_idtema'];
        $idmateria  = $vector_ask[$contador]['materia_idmateria'];
        $ask        = $vector_ask[$contador]['pregunta'];
        $img        = $vector_ask[$contador]['img'];
        #$ask    = mostrar_comilla_simple_ask ($ask);
        $ask    = htmlspecialchars_decode($ask);
        $ask    = str_replace("\r","<br>",$ask);
        $ask    = recortar_ask ($ask,80);
        #$ask = utf8_decode($ask);
        echo "<tr>";
        echo    "<th>";
        echo      $indice = 1 + $contador;
        echo    "</th>";
        echo    "<td class='mdl-data-table__cell--non-numeric'>";
        echo      "$ask";
        echo    "</td>";
        echo    "<td>";
        echo      "<form method='post' action='./' enctype='multipart/form-data'>
                   <input type='hidden' name='materia' value='$preguntas_materia'>";
        echo      "<input type='hidden' name='edit_idask' value='$idask'>";
        echo      "<button type='submit' name='contenido' value='guardar_edit_ask' class='mdl-button mdl-js-button mdl-button--icon mdl-button--colored'>";
        echo        "<i class='material-icons'>visibility</i>";
        echo      "</button>";
        echo      "</form>";
        echo    "</td>";
        echo    "<td>";
        echo      "<form method='post' action='./' enctype='multipart/form-data'>";
        echo      "<input type='hidden' name='materia' value='$preguntas_materia'>";
        echo      "<input type='hidden' name='idask' value='$idask'>";
        echo      "<input type='hidden' name='img' value='$img'>";
        echo      "<button type='submit' name='contenido' value='$preguntas_materia' class='mdl-button mdl-js-button mdl-button--icon mdl-button--colored'>";
        echo        "<i class='material-icons'>edit</i>";
        echo      "</button>";
        echo      "</form>";
        echo    "</td>";
        echo "</tr>";
      }
    }  
}


function nombre_materia ($preguntas_materia){
    switch ($preguntas_materia) {
    case 'sociales':
      echo  "Estudios Sociales";
      break;
    case 'matematicas':
      echo  "Matemáticas";
      break;
    case 'ciencias':
      echo "Ciencias Naturales";
      break;
    case 'lenguaje':
      echo "Lenguaje y Literatura";
      break;   
    default:
      # code...
      break;
  }
}

function materia ($materia){
    switch ($materia) {
    case 'sociales':
      echo  "Estudios Sociales";
      break;
    case 'matematicas':
      echo  "Matemáticas";
      break;
    case 'ciencias':
      echo "Ciencias Naturales";
      break;
    case 'lenguaje':
      echo "Lenguaje y Literatura";
      break;   
    default:
      # code...
      break;
  }
}

function ask ($idask){
    $vector_ask = consultar("select * from ask where idask = $idask;");
    $cantidad_ask = count( $vector_ask );
    if ( $cantidad_ask > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_ask; $contador ++ ) {
        $idask      = $vector_ask[$contador]['idask'];
        $idtema     = $vector_ask[$contador]['tema_idtema'];
        $idmateria  = $vector_ask[$contador]['materia_idmateria'];
        $ask        = $vector_ask[$contador]['pregunta'];
        $img        = $vector_ask[$contador]['img'];
        #$ask    = mostrar_comilla_simple_ask ($ask);
        $ask        = htmlspecialchars_decode($ask);
        #$ask    = str_replace("\r","<br>",$ask);
        echo "$ask";
      }
    }
}

function ask_con_img ($idask){
    $vector_ask_adjunto = consultar("select * from ask where idask = $idask;");
    $cantidad_ask_adjunto = count( $vector_ask_adjunto );
    if ( $cantidad_ask_adjunto > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_ask_adjunto; $contador ++ ) {
        $idask      = $vector_ask_adjunto[$contador]['idask'];
        $idtema     = $vector_ask_adjunto[$contador]['tema_idtema'];
        $idmateria  = $vector_ask_adjunto[$contador]['materia_idmateria'];
        $ask        = $vector_ask_adjunto[$contador]['pregunta'];
        $img        = $vector_ask_adjunto[$contador]['img'];
        $ask    = mostrar_comilla_simple_ask ($ask);
        $ask    = str_replace("\r","<br>",$ask);      
        
        echo "$ask";
        if ($img == "ninguna") {
          # nada...
        }else{
          echo "</br><center><img class='ilustracion'  src='.$img' alt='' /></center>";
          echo "<input type='hidden' name='img' value='$img'>";
        }
      }
    }
}


###### funcion que edita la pregunta en la bd ########

function recortar_ask($ask, $numero){ 
  if(strlen($ask) > $numero){ 
    $ask=substr($ask,0,$numero)."<i class='material-icons'>more_horiz</i>";
    #$ask = str_replace("&amp;#39", "'", $ask);
     }else{ 
      $ask=$ask;
      #$ask = str_replace("&amp;#39", "'", $ask);
     } 
        return $ask; 
}


# esta funcion edita una pregunta sin aadjuntar imagen y sin anular imagen
function editando_pregunta ($idask, $ask, $tema, $libro, $enlace1, $enlace2){ 
    $ask    = permitir_comilla_simple_ask ($ask);
    $libro = htmlspecialchars_decode($libro);
    $tema = htmlspecialchars_decode($tema);

    #actualizando pregunta
        $sql="
          UPDATE
            ask 
            SET
              pregunta   = '{$ask}'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );


    #echo "$tema <br>";
    #echo "$libro <br>";
    $enlaces = "$enlace1 $enlace2";
    #echo "$enlaces <br>";

  ###verificando la información asociada al ítem

    $vector_tema = consultar ("select idtema, tematica, referencia, libro_autor from ask, tema where tema_idtema = idtema and idask = $idask;");
   # $vector_tema = consultar("select * from tema where to_tsvector(tematica) @@ plainto_tsquery('$tema');");
    $cantidad_tema = count( $vector_tema );
    if ( $cantidad_tema > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_tema; $contador ++ ) {
        $idtema       = $vector_tema[$contador]['idtema'];
        $tematica     = $vector_tema[$contador]['tematica']; 
        $libro_autor  = $vector_tema[$contador]['libro_autor'];
        $referencia   = $vector_tema[$contador]['referencia'];
      }
    }

  ### comparando si existen cambios en la información
    if ($tematica == $tema && $referencia == $enlaces) {
      $libro  = permitir_comilla_simple_libro ($libro);
      $tema   = permitir_comilla_simple_tema ($tema);
        $sql="
          UPDATE
            tema 
            SET
              tematica = '{$tema}',
              referencia = '$enlaces',
              libro_autor = '{$libro}'
            WHERE 
              idtema ='$idtema';";
        #ejecutar sql
        $resultado = ejecutar( $sql );
        #echo "<br>bibliografia actualizada!!";
    }else{
    ## si existen cambios en todos los campos insertar un nuevo tema
      $libro  = permitir_comilla_simple_libro ($libro);
      $tema   = permitir_comilla_simple_tema ($tema);

        $sql="
          INSERT INTO 
            tema (tematica, referencia, libro_autor)
            VALUES ('{$tema}', '$enlaces', '{$libro}');";
        $resultado = ejecutar( $sql );

       $vector_detema = consultar ("select * from tema order by idtema desc;");
       $cantidad = count( $vector_detema );
        if ( $cantidad > 0 ) {
          for ( $contador = 0 ; $contador <= 0; $contador ++ ) {
            $idtema      = $vector_detema[$contador]['idtema'];
          }
        }

        if ($idtema) {
            $sql="
              UPDATE
                ask 
                SET
                  tema_idtema = $idtema
                WHERE 
                  idask = $idask;";
            #ejecutar sql
            $resultado = ejecutar( $sql );
            #echo "<br>bibliografia ingresada!!";
        }
        
    }
}



# esta funcion edita una pregunta sin aadjuntar imagen pero con anular imagen
function editando_ask_anular_imagen ($idask, $ask, $anular_img, $tema, $libro, $enlace1, $enlace2){ 
    $ask    = permitir_comilla_simple_ask ($ask);
    $enlaces = "$enlace1 $enlace2";
    $libro = htmlspecialchars_decode($libro);
    $tema = htmlspecialchars_decode($tema);



    #actualizando pregunta
        $sql="
          UPDATE
            ask 
            SET
              pregunta   = '{$ask}'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );

  ###verificando la información asociada al ítem

    $vector_tema = consultar ("select idtema, tematica, referencia, libro_autor from ask, tema where tema_idtema = idtema and idask = $idask;");
    echo $cantidad_tema = count( $vector_tema );
    if ( $cantidad_tema > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_tema; $contador ++ ) {
        $idtema       = $vector_tema[$contador]['idtema'];
        $tematica     = $vector_tema[$contador]['tematica']; 
        $libro_autor  = $vector_tema[$contador]['libro_autor'];
        $referencia   = $vector_tema[$contador]['referencia']; 
      }
    }

  ### comparando si existen cambios en la información
    if ($tematica == $tema && $referencia == $enlaces) {

      if ($anular_img) {
        $libro  = permitir_comilla_simple_libro ($libro);
        $tema   = permitir_comilla_simple_tema ($tema);

        #primero anular imagen
        $sql="
          UPDATE
            ask 
            SET
              img   = 'ninguna'
            WHERE 
              idask ='$idask';";
        $resultado = ejecutar( $sql );

        #ahora actualizar tema
          $sql="
            UPDATE
              tema 
              SET
                tematica = '{$tema}',
                referencia = '$enlaces',
                libro_autor = '{$libro}'
              WHERE 
                idtema ='$idtema';";
          #ejecutar sql
          $resultado = ejecutar( $sql );
          #echo "<br>bibliografia actualizada (anulando imagen)!!";

      }else{
        $libro  = permitir_comilla_simple_libro ($libro);
        $tema   = permitir_comilla_simple_tema ($tema);
        #de lo contrario solo actualizar tema
          $sql="
            UPDATE
              tema 
              SET
                tematica = '{$tema}',
                referencia = '$enlaces',
                libro_autor = '{$libro}'
              WHERE 
                idtema ='$idtema';";
          #ejecutar sql
          $resultado = ejecutar( $sql );
          #echo "<br>bibliografia actualizada (no anular img)!!";
      }


    }else{
      #existen camnios en toda la tupla, el paso siguente es insertar un nuevo tema
      $libro  = permitir_comilla_simple_libro ($libro);
      $tema   = permitir_comilla_simple_tema ($tema);

        $sql="
          INSERT INTO 
            tema (tematica, referencia, libro_autor)
            VALUES ('{$tema}', '$enlaces', '{$libro}');";
        $resultado = ejecutar( $sql );

       $vector_detema = consultar ("select * from tema order by idtema desc;");
       $cantidad = count( $vector_detema );
        if ( $cantidad > 0 ) {
          for ( $contador = 0 ; $contador <= 0; $contador ++ ) {
            $idtema      = $vector_detema[$contador]['idtema'];
          }
        }

        #actualizan el idtema en la tabla ask
        if ($idtema) {
            $sql="
              UPDATE
                ask 
                SET
                  tema_idtema = $idtema
                WHERE 
                  idask = $idask;";
            #ejecutar sql
            $resultado = ejecutar( $sql );
            #echo "<br>bibliografia ingresada!!";
        }

        # asegurace si existe anular imagen
        if ($anular_img) {
        $sql="
          UPDATE
            ask 
            SET
              img   = 'ninguna'
            WHERE 
              idask ='$idask';";
        $resultado = ejecutar( $sql );
        }
    }
}


# editar pregunta con imagen adjuntada
function editando_ask_img ($idask, $ask, $imagen, $tipo_imagen, $nombreimagen, $anular_img, $tema, $libro, $enlace1, $enlace2){
    #actualizando pregunta
        $sql="
          UPDATE
            ask 
            SET
              pregunta   = '{$ask}'
            WHERE 
              idask ='$idask';";
        #ejecutar sql
        $resultado = ejecutar( $sql );

      switch ($tipo_imagen) {
        case 'image/jpeg':
          $nombreimagen=random_name().".jpeg";
          $rutadestino= "../ilustracion/$nombreimagen";
          $rutabasededato = "./ilustracion/$nombreimagen";
          break;
        case 'image/png':
          $nombreimagen=random_name().".png";
          $rutadestino= "../ilustracion/$nombreimagen";
          $rutabasededato = "./ilustracion/$nombreimagen";
          break;
        case 'image/gif':
          $nombreimagen=random_name().".gif";
          $rutadestino= "../ilustracion/$nombreimagen";
          $rutabasededato = "./ilustracion/$nombreimagen";
          break;
        default:
          # code...
          break;
      }

    if(move_uploaded_file($imagen, $rutadestino)){
      $ask= permitir_comilla_simple_ask ($ask);
      editando_ask_anular_imagen ($idask, $ask, $anular_img, $tema, $libro, $enlace1, $enlace2);
          $sql="
            UPDATE
              ask 
              SET
                img        = '$rutabasededato'
              WHERE 
                idask ='$idask';";
          #ejecutar sql
          $resultado = ejecutar( $sql );
    }else{
      echo "Algo malo ocurre :(";
    }
}

#mostrar opciones de cada pregunta en vista
function listar_opciones ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask;");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $idopcion = $vector_opc[$contador]['idopcion'];
        $opcion   = $vector_opc[$contador]['opcion' ];
        #$opcion   = mostrar_comilla_simple_ask ($opcion);
        $option   = htmlspecialchars_decode($opcion);
        
        echo"<li class='list-unstyled'>$opcion</li>";
        
      }
    }  
}

############# mostrar opciones de cada pregunta para editar #################################
function a_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'a';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion                  = $vector_opc[$contador]['opcion'];
        #$opcion   = mostrar_comilla_simple_ask ($opcion);
        $option   = htmlspecialchars_decode($opcion);
        echo "$opcion";
      }
    }  
}

function b_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'b';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        #$opcion   = mostrar_comilla_simple_ask ($opcion);
        $option   = htmlspecialchars_decode($opcion);        echo "$opcion";
      }
    }  
}

function c_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'c';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        #$opcion   = mostrar_comilla_simple_ask ($opcion);
        $option   = htmlspecialchars_decode($opcion);        echo "$opcion";
      }
    }  
}

function d_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'd';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        #$opcion   = mostrar_comilla_simple_ask ($opcion);
        $option   = htmlspecialchars_decode($opcion);        echo "$opcion";
      }
    }  
}

/*function e_opcion_edit ($idask){
    $vector_opc = consultar("select * from opcion where ask_idask=$idask and literal = 'e';");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc; $contador ++ ) {
        $opcion   = $vector_opc[$contador]['opcion'];
        $opcion   = mostrar_comilla_simple_ask ($opcion);
        echo "$opcion";
      }
    }  
}
*/

# funcion para mostrar opcion true en radio button vista previa
function opction_true ($idask, $true){
    $vector_opc_true = consultar("select * from opcion where ask_idask=$idask and truefalse_idtruefalse=2;");
    $cantidad_opc_true = count( $vector_opc_true );
    if ( $cantidad_opc_true > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc_true; $contador ++ ) {
        $literal   = $vector_opc_true[$contador]['literal'];
      }
      if ($literal==$true) {
        echo "checked";
      }else{
        echo "disabled";
      }
    }  
}

# funcion para mostrar opcion true en radio button editar
function opction_true_edit ($idask, $true){
    $vector_opc_true_edit = consultar("select * from opcion where ask_idask=$idask and truefalse_idtruefalse=2;");
    $cantidad_opc_true_edit = count( $vector_opc_true_edit );
    if ( $cantidad_opc_true_edit > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_opc_true_edit; $contador ++ ) {
        $literal   = $vector_opc_true_edit[$contador]['literal'];
      }
      if ($literal==$true) {
        echo "checked";
      }
    }  
}



# funcion para editar opciones en bd
function editando_opciones ($idask, $opc_a, $opc_b, $opc_c, $opc_d, $options_true){  
    $opc_a= permitir_comilla_simple_ask ($opc_a);
    $opc_b= permitir_comilla_simple_ask ($opc_b);
    $opc_c= permitir_comilla_simple_ask ($opc_c);
    $opc_d= permitir_comilla_simple_ask ($opc_d);
    #$opc_e= permitir_comilla_simple_ask ($opc_e);

    $vector_opc = consultar("select * from opcion where ask_idask=$idask;");
    $cantidad_opc = count( $vector_opc );
    if ( $cantidad_opc > 0 && $cantidad_opc <= 4 && $opc_a && $opc_b && $opc_c && $opc_d) {
      switch ($options_true) {
        case 'a':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'd';
          ";
          $resultado = ejecutar( $sql );
        break;
        case 'b':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'd';
          ";
          $resultado = ejecutar( $sql );
        break;
        case 'c':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'd';
          ";
          $resultado = ejecutar( $sql );
        break;
        case 'd':
          $sql="
            UPDATE opcion SET opcion = '{$opc_a}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'a';
            UPDATE opcion SET opcion = '{$opc_b}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'b';
            UPDATE opcion SET opcion = '{$opc_c}', truefalse_idtruefalse = '1' WHERE ask_idask ='$idask' and literal = 'c';             
            UPDATE opcion SET opcion = '{$opc_d}', truefalse_idtruefalse = '2' WHERE ask_idask ='$idask' and literal = 'd';
          ";
          $resultado = ejecutar( $sql );
        break;
        default:
        ####
          break;
      }
    }elseif (!$opc_a || !$opc_b || !$opc_c || !$opc_d) {
      echo "<small class='mdl-badge' data-badge='!'><i>No se pudo actualizar las opciones! llene todas las opciones</i></small>";
    }else{

      switch ($options_true) {
        case 'a':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        case 'b':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        case 'c':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        case 'd':
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('2', '$idask', '{$opc_d}', 'd', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
        default:
          $sql="
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_a}', 'a', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_b}', 'b', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_c}', 'c', 'ninguna');
            INSERT INTO 
              opcion (truefalse_idtruefalse, ask_idask, opcion, literal, imagen)
              VALUES ('1', '$idask', '{$opc_d}', 'd', 'ninguna');
              ";
          $resultado = ejecutar( $sql );
          break;
      }
    }
}


#funciones para editar la referencia TEMA
function edit_tema ($idask){
    $vector_tema = consultar("SELECT tema_idtema, tematica FROM ask, tema WHERE idtema = tema_idtema and idask = '$idask';");
    $cantidad_tema = count( $vector_tema );
    if ( $cantidad_tema > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_tema; $contador ++ ) {
        $idtema = $vector_tema[$contador]['tema_idtema'];
        $tema   = $vector_tema[$contador]['tematica'];
        #$tema   = mostrar_comilla_simple_tema ($tema);
        $tema   = htmlspecialchars_decode($tema);
        echo $tema;
      }
    }
}

#funciones para editar la referencia LIBRO
function edit_libro ($idask){
    $vector_libro = consultar("SELECT tema_idtema, libro_autor FROM ask, tema WHERE idtema = tema_idtema and idask = '$idask';");
    $cantidad_libro = count( $vector_libro );
    if ( $cantidad_libro > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_libro; $contador ++ ) {
        $idtema = $vector_libro[$contador]['tema_idtema'];
        $libro   = $vector_libro[$contador]['libro_autor'];
        #$libro   = mostrar_comilla_simple_libro ($libro);
        $libro   = html_entity_decode($libro);
        echo $libro;
      }
    } 
}

#funciones para editar la referencia ENLACE1
function edit_enlace1 ($idask){
    $vector_enlace1 = consultar("SELECT tema_idtema, referencia FROM ask, tema WHERE idtema = tema_idtema and idask = '$idask';");
    $cantidad_enlace1= count( $vector_enlace1 );
    if ( $cantidad_enlace1 > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_enlace1; $contador ++ ) {
        $idtema = $vector_enlace1[$contador]['tema_idtema'];
        $enlace1   = $vector_enlace1[$contador]['referencia'];
        $enlace1 = explode(" ","$enlace1");
        echo $enlace1[0];
      }
    } 
}

#funciones para editar la referencia ENLACE2
function edit_enlace2 ($idask){
    $vector_enlace2 = consultar("SELECT tema_idtema, referencia FROM ask, tema WHERE idtema = tema_idtema and idask = '$idask';");
    $cantidad_enlace2= count( $vector_enlace2 );
    if ( $cantidad_enlace2 > 0 ) {
      for ( $contador = 0 ; $contador < $cantidad_enlace2; $contador ++ ) {
        $idtema = $vector_enlace2[$contador]['tema_idtema'];
        $enlace2   = $vector_enlace2[$contador]['referencia'];
        $enlace2 = explode(" ","$enlace2");
        echo $enlace2[1];
      }
    } 
}



function permitir_comilla_simple_ask ($ask){
    $ask  = str_replace("'", "&#39", $ask);
    return $ask; 
}
function mostrar_comilla_simple_ask ($ask){
  $ask= str_replace("&amp;#39", "'", $ask);
  return $ask; 
}


function permitir_comilla_simple_libro ($libro){
    $libro  = str_replace("'", "&#39", $libro);
    return $libro;
}
function mostrar_comilla_simple_libro ($libro){
  $libro= str_replace("&amp;#39", "'", $libro);
  return $libro; 
}



function permitir_comilla_simple_tema ($tema){
    $tema  = str_replace("'", "&#39", $tema);
    return $tema;
}
function mostrar_comilla_simple_tema ($tema){
  $tema= str_replace("&amp;#39", "'", $tema);
  return $tema; 
}


function random_name(){

  $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz1234567890";
  $cad = "";
  for($i=0;$i<10;$i++) {
      $cad .= substr($str,rand(0,120),1);
  }
  return $cad;
}



######### funciones para la sesion ##################
function validar_usuario() {
  include "./configuraciones/principal.php";
   $contenido = @ $_REQUEST['contenido'];

  if ( $contenido == "iniciar" ) {
       $correo =  $_REQUEST['correo'];
       $contraseña  =  $_REQUEST['contraseña'];
       $contraseña  = md5($contraseña);

         $sql = "
          select
            *
          from
            admon
          where
            pass   = '{$contraseña}' and
            correo     = '$correo';
            ";
       $existe1 = consultar ( $sql);
       $verficar_existencia1 = count($existe1);
        
     if ( $verficar_existencia1 ) {     
     $vector_usuario = consultar("select * from admon where pass = '{$contraseña}' and correo = '$correo';");
     $existe_usuario = count( $vector_usuario );      
      if ( $existe_usuario > 0 ) {
        for ( $contador = 0 ; $contador < $existe_usuario ; $contador ++ ) {
            ( $contador + 1 );
            $id = $vector_usuario[$contador]['idadmon'];
            $correo = $vector_usuario[$contador]['correo'];
            $nombres = $vector_usuario[$contador]['nombres'];
            $apellido = $vector_usuario[$contador]['apellidos'];

            $_SESSION["correo"] = $correo;
            $_SESSION["idadmon"] = $id;
            $_SESSION["nombres"] = $nombres;
            $resultado = TRUE;
          }
      }else{
        echo "
            <div class='mdl-color--white mdl-layout__header-row'>
              <span id='error' class='material-icons mdl-color-text--cyan mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='i'>perm_identity</span>
                <div class='mdl-color--cyan mdl-tooltip' for='error'>
                  Probablemente introdujo mal su correo o contrase&ntilde;a, <br> intente de nuevo
                </div>
            </div>
        ";
      }
    }else{
        echo "
            <div class='mdl-color--white mdl-layout__header-row'>
              <span id='error' class='material-icons mdl-color-text--cyan mdl-badge mdl-badge--overlap mdl-badge--no-background' data-badge='i'>perm_identity</span>
                <div class='mdl-color--cyan mdl-tooltip' for='error'>
                  Probablemente introdujo mal su correo o contrase&ntilde;a, <br> intente de nuevo
                </div>
            </div>
        ";
    }
        
  }
    

  if ( $contenido == "cerrarsesion" ) {
      $_SESSION["correo"] = NULL;
      $_SESSION["idadmon"]  = NULL;
      $_SESSION["nombres"] = NULL;
      session_destroy();
    unset( $_SESSION["correo"] );
    unset( $_SESSION["idadmon"] );
    unset( $_SESSION["nombres"] );
  }
}


 ### BD ####################

  function conectar() {
    include "./configuraciones/principal.php";
    $parametros  = "host='$SERVIDOR_DE_BASE_DE_DATOS' ";
    $parametros .= "port='5432' ";
    $parametros .= "dbname='$BASE_DE_DATOS' ";
    $parametros .= "user='$USUARIO_DE_BASE_DE_DATOS' ";
    $parametros .= "password='$CLAVE_DE_BASE_DE_DATOS'";
    $conexion = @ pg_connect( $parametros );
    if ( !$conexion ) {
      #echo "<br>No se pudo establecer la conexi&oacute;n a la base de datos<br>";
    }
    return $conexion;
  };

  function existe_conexion () {
    include "./configuraciones/principal.php";
    $parametros  = "host='$SERVIDOR_DE_BASE_DE_DATOS' ";
    $parametros .= "port='5432' ";
    $parametros .= "dbname='$BASE_DE_DATOS' ";
    $parametros .= "user='$USUARIO_DE_BASE_DE_DATOS' ";
    $parametros .= "password='$CLAVE_DE_BASE_DE_DATOS'";
    $conexion = @ pg_connect( $parametros );
    if ( $conexion ) {
      $resultado = TRUE;
      pg_close( $conexion );
    } else {
      $resultado = FALSE;
    }
    return $resultado;
  }

  function consultar( $sql ){
    $conexion = conectar();
    $resultado = array();
    if ( $conexion ) {
      $consulta = @ pg_query( $conexion, $sql );
      if ( $consulta ) {
        while ( $fila = pg_fetch_array( $consulta ) ) {
            $resultado[] = $fila;
        }
      } else {
        # Esta parte la hice para depurado, comentar esta linea si no se desea ver los resultados
       echo "<br>No se ejecuto la sentencia <br><pre> $sql</pre> <br>";
      }
    } else {
      echo "<br>No hay conexi&oacute;n<br>";
    }
    return $resultado;
  }

  function consultar2( $sql2 ){
    $conexion = conectar();
    $resultado = array();
    if ( $conexion ) {
      $consulta = @ pg_query( $conexion, $sql2 );
      if ( $consulta ) {
        while ( $fila = pg_fetch_array( $consulta ) ) {
            $resultado[] = $fila;
        }
      } else {
        # Esta parte la hice para depurado, comentar esta linea si no se desea ver los resultados
       #echo "<br>No se ejecuto la sentencia <br><pre>sql , $sql2</pre> <br>";
      }
    } else {
      echo "<br>No hay conexi&oacute;n<br>";
    }
    return $resultado;
  }

  function ejecutar( $sql ){
    $conexion = conectar();
    $resultado = FALSE;
    if ( $conexion ) {
      $consulta = @ pg_query( $conexion, htmlentities($sql) );
      if ( $consulta ) {
        $resultado = TRUE;
      } else {
        # Esta parte la hice para depurado, comentar esta linea si no se desea ver los resultados
        #echo "<br>No se ejecuto la sentencia <br><pre>$sql</pre> <br>";
      }
    } else {
      echo "<br>No hay conexi&oacute;n<br>";
    }
    return $resultado;
  }
  


?>
