<?
 ################################################################################
 #	SISTEMA DE TEST PRE-PAES 2016 												# 
 # Autor : Manuel Antonio Molina												#
 #		   manuel.ntonio@gmail.com												#
 #	Este programa es software libre: usted puede redistribuirlo y / o         	#
 # 	modificarlo bajo los términos de la GNU General Public License publicada  	#
 #	por la Free Software Foundation, bien de la versión 3 de la Licencia, o   	#
 #	cualquier versión posterior. 												#
 #	Vea el archivo recursos/LICENCIA acerca de la utilización de este software. #
 ################################################################################
 date_default_timezone_set("America/El_Salvador");
 header("Cache-Control: no-cache");
 header("Pragma: no-cache");
 ini_set("session.cookie_lifetime","15400");
 ini_set("session.gc_maxlifetime","15400");
 session_start();
 include "./funciones/funciones.php";
  actualizar_datos_usuario ();
  head ();
  validar_usuario();
  body ();
  cierre_body ();
?>
